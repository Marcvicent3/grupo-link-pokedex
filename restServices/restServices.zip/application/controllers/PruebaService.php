<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class PruebaService extends REST_Controller
{
    public function __construct(){
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");
        parent::__construct();
        $this->load->database();
    }

    public function index_get(){
        $respuesta = 'PruebaService-index_get()';
        $this->response($respuesta);
    }

    public function obtenerPruebas_get(){
        $this->db->SELECT('prue.*, cur.Grado, cur.Paralelo');
        $this->db->from('prueba prue');
        $this->db->join('curso_prueba curprue', 'prue.Id_Prueba = curprue.Id_Prueba');
        $this->db->join('curso cur', 'curprue.Id_Curso = cur.Id_Curso');
        $this->db->order_by('cur.Paralelo ASC, prue.Titulo ASC');
        $queryPruebas = $this->db->get();

        if (isset($queryPruebas)){
            $cantidadFilas = $queryPruebas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'pruebas' => $queryPruebas->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }

            $this->response($respuesta);
        }
    }

    public function obtenerTemas_get(){
        $this->db->SELECT('*');
        $this->db->from('tema');
        $this->db->order_by('Tema ASC');
        $queryTemas = $this->db->get();

        if (isset($queryTemas)){
            $cantidadFilas = $queryTemas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'temas' => $queryTemas->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }

            $this->response($respuesta);
        }
    }

    // **TODOS LOS INGRESAR DESDE AQUÍ**

    public function ingresarPrueba_post(){
        $data = $this->post();

        $prueba = $data['Prueba'];
        $preguntas = $data['Preguntas'];
        $temas = $data['Temas'];

        $datosPrueba = [
            'Titulo' => $prueba['Titulo'],
            'Password' => $prueba['Password'],
            'Fecha_Inicio' => $prueba['Fecha_Inicio'],
            'Fecha_Fin' => $prueba['Fecha_Fin'],
            'Intentos' => $prueba['Intentos'],
            'NotaTotal' => $prueba['NotaTotal'],
            'NotaMin' => $prueba['NotaMin'],
            'Observacion' => $prueba['Observacion']
        ];
        if ($prueba['Id_Prueba'] == null){
            $this->db->insert('prueba', $datosPrueba);             // ingresamos los datos de la nueva prueba
            $nuevoId = $this->db->insert_id();

            $datosCursoPrueba = [
                'Id_Curso' => $data['Curso'],
                'Id_Prueba' => $nuevoId
            ];
            $this->db->insert('curso_prueba', $datosCursoPrueba);         // ingresamos los datos en curso_prueba
            $nuevoIdCurPrue = $this->db->insert_id();

            foreach ($preguntas as $preg){              // ingresamos todas las preguntas de la prueba
                $datosCursoPruePreg = [
                    'Id_CursoPrueba' => $nuevoIdCurPrue,
                    'Id_Pregunta' => $preg['Id_Pregunta']
                ];
                $this->db->insert('cursopruebapregunta', $datosCursoPruePreg);
            }

            foreach ($temas as $tema){          // ingresamos todos los temas de la prueba
                $datosPruebaTema = [
                    'Id_Prueba' => $nuevoId,
                    'Id_Tema' => $tema['Id_Tema']
                ];
                $this->db->insert('prueba_temas', $datosPruebaTema);
            }

            $respuesta = array(
                'error' => false,
                'mensaje' => 'Prueba ingresada Correctamente'
            );
        }else{
            $this->db->where('Id_Prueba', $prueba['Id_Prueba']);          // actualizamos los datos de la prueba
            $this->db->update('prueba', $datosPrueba);

            $this->db->SELECT('Id_CursoPrueba');                       // Buscamos el Id_CursoPrueba para acceder a las preguntas
            $this->db->from('curso_prueba');
            $this->db->where('Id_Prueba', $prueba['Id_Prueba']);
            $queryCursoPrueba = $this->db->get();
            $resultCursoPrueba =  $queryCursoPrueba->result_array();

            $datosCursoPrueba = [
                'Id_Curso' => $data['Curso']
            ];
            $this->db->where('Id_CursoPrueba', $resultCursoPrueba[0]['Id_CursoPrueba']);          // actualizamos el curso por si se cambio
            $this->db->update('curso_prueba', $datosCursoPrueba);

            $this->db->where('Id_CursoPrueba', $resultCursoPrueba[0]['Id_CursoPrueba']);    // borramos todas las preguntas de esa prueba
            $this->db->delete('cursopruebapregunta');

            foreach ($preguntas as $preg){              // ingresamos nuevamente todas las preguntas de la prueba
                $datosCursoPruePreg = [
                    'Id_CursoPrueba' => $resultCursoPrueba[0]['Id_CursoPrueba'],
                    'Id_Pregunta' => $preg['Id_Pregunta']
                ];
                $this->db->insert('cursopruebapregunta', $datosCursoPruePreg);
            }

            $this->db->where('Id_Prueba', $prueba['Id_Prueba']);    // borramos todas los temas de esa prueba
            $this->db->delete('prueba_temas');   

            foreach ($temas as $tema){          // ingresamos nuevamente todos los temas de la prueba
                $datosPruebaTema = [
                    'Id_Prueba' => $prueba['Id_Prueba'],
                    'Id_Tema' => $tema['Id_Tema']
                ];
                $this->db->insert('prueba_temas', $datosPruebaTema);
            }

            $respuesta = array(
                'error' => false,
                'mensaje' => 'Prueba actualizada Correctamente'
            );
        }

        $this->response($respuesta);
    }

    public function ingresarTema_post(){
        $data = $this->post();
        $id = $data['Id_Tema'];
        $datos = array(
            'Tema' => $data['Tema'],
        );

        if (($id == null)) {
            $this->db->insert('tema', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Tema guardado correctamente',
                'id_nuevo' => $nuevoId
            );
        } else {
            $this->db->where('Id_Tema', $id);
            $this->db->update('tema', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Tema actualizado correctamente'
                );
        }
        $this->response($respuesta);
    }

    public function ingresarPregunta_post(){
        $data = $this->post();
        $id = $data['Id_Pregunta'];
        $datos = array(
            'Encabezado' => $data['Encabezado'],
            'Tipo' => $data['Tipo'],
            'Valor' => $data['Valor']
        );

        if (($id == null)) {
            $this->db->insert('preguntas', $datos);
            $nuevoId = $this->db->insert_id();

            $datosPruePreg = array(
                'Id_Tema' => $data['Id_Tema'],
                'Id_Pregunta' => $nuevoId
            );
            $this->db->insert('tema_preguntas', $datosPruePreg);

            $respuesta = array(
                'error' => false,
                'mensaje' => 'Pregunta se guardó correctamente',
                'id_nuevo' => $nuevoId
            );
        } else {
            $this->db->where('Id_Pregunta', $id);
            $this->db->update('preguntas', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'La pregunta se actualizó correctamente'
                );
        }
        $this->response($respuesta);
    }

    public function ingresarRespuestas_post(){
        $data = $this->post();
        if ($data['Tipo'] != 'MC'){
            $respuesta = $data['Respuesta'];
            $id = $respuesta['Id_Respuesta'];
            $datos = array(
                'Respuesta' => $respuesta['Respuesta'],
                'Valor' => $respuesta['Valor']
            );
    
            if (($id == null)) {
                $this->db->insert('respuestas', $datos);
                $nuevoId = $this->db->insert_id();
    
                $datosRespPreg = array(
                    'Id_Pregunta' => $respuesta['Id_Pregunta'],
                    'Id_Respuesta' => $nuevoId
                );
                $this->db->insert('respuesta_preguntas', $datosRespPreg);
    
                $respuestaResp = array(
                    'error' => false,
                    'mensaje' => 'Respuesta se guardó correctamente',
                );
            } else {
                $this->db->where('Id_Respuesta', $id);
                $this->db->update('respuestas', $datos);
                    $respuestaResp = array(
                        'error' => false,
                        'mensaje' => 'La respuesta se actualizó correctamente'
                    );
            }
        }else{
            $respuesta = $data['Respuesta'];
            foreach($respuesta as $respta){
                if ($respta['Respuesta'] != null || $respta['Respuesta'] != ""){
                    $id = $respta['Id_Respuesta'];
                    $datos = array(
                        'Respuesta' => $respta['Respuesta'],
                        'Valor' => $respta['Valor']
                    );
            
                    if (($id == null)) {
                        $this->db->insert('respuestas', $datos);
                        $nuevoId = $this->db->insert_id();
            
                        $datosRespPreg = array(
                            'Id_Pregunta' => $respta['Id_Pregunta'],
                            'Id_Respuesta' => $nuevoId
                        );
                        $this->db->insert('respuesta_preguntas', $datosRespPreg);
                    } else {
                        $this->db->where('Id_Respuesta', $id);
                        $this->db->update('respuestas', $datos);
                    }
                }
            }
            $respuestaResp = array(
                'error' => false,
                'mensaje' => 'Respuesta se guardó correctamente',
            );
        }
        $this->response($respuestaResp);
    }

    public function ingresarEstudiantePru_post(){
        $data = $this->post();

        $id = $data['Id_EstudiantePrueba'];

        $datos = array(
            'Id_Estudiante' => $data['Id_Estudiante'],
            'Id_Prueba' => $data['Id_Prueba'],
            'Nota' => $data['Nota'],
            'Num_Intento' => $data['Num_Intento']
        );

        if (($id == null)) {
            $this->db->insert('estudiante_prueba', $datos);
            $nuevoId = $this->db->insert_id();

            $respuesta = array(
                'error' => false,
                'id_nuevo' => $nuevoId
            );
        } else {
            $this->db->where('Id_EstudiantePrueba', $id);
            $this->db->update('estudiante_prueba', $datos);

            $respuesta = array(
                'error' => false
            );
        }
        
        $this->response($respuesta);
    }

    public function ingresarEstudiantePruHecho_post(){
        $data = $this->post();
        $PruHecho = $data['PruHecho'];
        
        $datosEstPru = array(
            'Nota' => $data['Nota']
        );

        $this->db->where('Id_EstudiantePrueba', $data['Id_EstudiantePrueba']);
        $this->db->update('estudiante_prueba', $datosEstPru);

        $this->db->where('Id_EstudiantePrueba', $data['Id_EstudiantePrueba']);
        $this->db->delete('prueba_hecha');

        foreach($PruHecho as $pru){
            $datosPruHecho = array(
                'Id_EstudiantePrueba' => $data['Id_EstudiantePrueba'],
                'Id_Pregunta' => $pru['Id_Pregunta'],
                'Id_Respuesta' => $pru['Id_Respuesta'],
                'Respuesta' => $pru['Respuesta']
            );
            $this->db->insert('prueba_hecha', $datosPruHecho);
        }

        $respuesta = array(
            'error' => false,
            'mensaje' => 'Prueba se guardó correctamente'
        );
        
        $this->response($respuesta);
    }


    /**TODOS LOS BUSCAR DESDE AQUÍ**/

    public function buscarDatosPrueba_post(){
        $data = $this->post();

        $this->db->SELECT('tem.*');                 // Obtenemos los temas de la prueba
        $this->db->from('prueba_temas pruetem');
        $this->db->where('pruetem.Id_Prueba', $data['Id_Prueba']);
        $this->db->join('tema tem', 'pruetem.Id_Tema = tem.Id_Tema');
        $queryTemas = $this->db->get();
        $cantTemas = $queryTemas->num_rows();

        $listado = array();
        if($cantTemas > 0){                        // Obtenemos todas las preguntas de los temas de la prueba
            $resultTemas = $queryTemas->result_array();
            for($i=0; $i<$cantTemas; $i++){
                $this->db->SELECT('tempre.Id_Tema, preg.*');
                $this->db->from('tema_preguntas tempre');
                $this->db->where('tempre.Id_Tema', $resultTemas[$i]['Id_Tema']);
                $this->db->join('preguntas preg', 'tempre.Id_Pregunta = preg.Id_Pregunta');
                $queryPreguntas = $this->db->get();
                if(isset($queryPreguntas)){
                    $listado = array_merge($listado, $queryPreguntas->result_array());
                }
            }
        }

        $this->db->SELECT('curprue.Id_Curso, curpruepreg.*');                 // Obtenemos todos los Ids de las preguntas generadas de esa prueba
        $this->db->from('curso_prueba curprue');
        $this->db->where('curprue.Id_Prueba', $data['Id_Prueba']);
        $this->db->join('cursopruebapregunta curpruepreg', 'curprue.Id_CursoPrueba = curpruepreg.Id_CursoPrueba');
        $queryPreguntasGen = $this->db->get();
        $cantPreguntasGen = $queryPreguntasGen->num_rows();

        $idCurso = 0;
        $listadoPregGen = array();
        if($cantPreguntasGen > 0){                        // Obtenemos los datos de todas las preguntas generadas
            $resultPreguntasGen = $queryPreguntasGen->result_array();
            $idCurso = $resultPreguntasGen[0]['Id_Curso'];
            for($i=0; $i<$cantPreguntasGen; $i++){
                $this->db->SELECT('tempre.Id_Tema, preg.*');
                $this->db->from('preguntas preg');
                $this->db->where('preg.Id_Pregunta', $resultPreguntasGen[$i]['Id_Pregunta']);
                $this->db->join('tema_preguntas tempre', 'preg.Id_Pregunta = tempre.Id_Pregunta');
                $queryPreguntasGeneradas = $this->db->get();
                if(isset($queryPreguntasGeneradas)){
                    $listadoPregGen = array_merge($listadoPregGen, $queryPreguntasGeneradas->result_array());
                }
            }
        }

        $this->db->SELECT('Id_EstudiantePrueba');                 // Obtenemos el Id de estudiante_prueba para saber si ya se realizo esta prueba
        $this->db->from('estudiante_prueba');
        $this->db->where('Id_Prueba', $data['Id_Prueba']);
        $queryPruHecho = $this->db->get();
        
        if(isset($queryTemas) && sizeof($listado) && sizeof($listadoPregGen) && isset($queryPruHecho)){
            $cantRegistros = $queryPruHecho->num_rows();             //obtenemos la cant de registros de la Prueba hecha para saber si ya se ha realizado al menos una vez

            $respuesta = array(
                'temas' => $queryTemas->result_array(),
                'preguntas' => $listado,
                'idCurso' => $idCurso,
                'preguntasGen' => $listadoPregGen,
                'pruRealizada' => $cantRegistros
            );
        }
        $this->response($respuesta);
    }

    public function buscarPruebasEstudiante_post(){
        $data = $this->post();

        $this->db->SELECT('pru.Id_Prueba, pru.Titulo, pru.Fecha_Inicio, pru.Fecha_Fin, pru.Intentos, pru.NotaTotal');
        $this->db->from('curso_prueba');
        $this->db->where('curso_prueba.Id_Curso', $data['Curso']);
        $this->db->join('prueba pru', 'curso_prueba.Id_Prueba = pru.Id_Prueba');
        $queryPruebas = $this->db->get();

        $this->db->SELECT('Id_EstudiantePrueba, Id_Prueba, Nota');
        $this->db->from('estudiante_prueba');
        $this->db->where('Id_Estudiante', $data['Estudiante']);
        $queryEstudiantes = $this->db->get();

        if(isset($queryPruebas) && isset($queryEstudiantes)){
            $cantidadFilas = $queryPruebas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'pru' => $queryPruebas->result_array(),
                    'pru_estudiantes' => $queryEstudiantes->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarPruebasHechas_post(){
        $data = $this->post();

        $this->db->SELECT('estu.Id_Estudiante, estu.Nombres, estu.Apellidos, estprub.Nota');
        $this->db->from('estudiante_prueba estprub');
        $this->db->where('estprub.Id_Prueba', $data['Id_Prueba']);
        $this->db->join('estudiante estu', 'estprub.Id_Estudiante = estu.Id_Estudiante');
        $queryPruebas = $this->db->get();

        if(isset($queryPruebas)){
            $cantidadFilas = $queryPruebas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'pru_hechas' => $queryPruebas->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarPreguntasPruebas_post(){
        $data = $this->post();

        $this->db->SELECT('Password');
        $this->db->from('prueba');
        $this->db->where('Id_Prueba', $data['Id_Prueba']);
        $queryPw = $this->db->get();
        $fila = $queryPw->row();
        
        if (isset($queryPw)){
            $this->db->SELECT('pre.*, resp.Id_Respuesta, resp.Respuesta, resp.Valor as ValorResp');
            $this->db->from('prueba_temas prute');
            $this->db->where('prute.Id_Prueba', $data['Id_Prueba']);
            $this->db->join('tema tm', 'prute.Id_Tema = tm.Id_Tema');
            $this->db->join('tema_preguntas tmpre', 'tm.Id_Tema = tmpre.Id_Tema');
            $this->db->join('preguntas pre', 'tmpre.Id_Pregunta = pre.Id_Pregunta');
            $this->db->join('respuesta_preguntas respre', 'pre.Id_Pregunta = respre.Id_Pregunta');
            $this->db->join('respuestas resp', 'respre.Id_Respuesta = resp.Id_Respuesta');
            $queryPreguntas = $this->db->get();
    
            if(isset($queryPreguntas)){
                $cantidadFilas = $queryPreguntas->num_rows();
                if($cantidadFilas > 0){
                    $respuesta = array(
                        'encontrado' => true,
                        'pw' => $fila->Password,
                        'preguntas' => $queryPreguntas->result_array()
                    );
                }else{
                    $respuesta = array(
                        'encontrado' => false
                    );
                }
            }
        }else{
            $respuesta = array(
                'encontrado' => false
            );
        }

        $this->response($respuesta);
    }

    public function buscarPreguntasPruebasResp_post(){
        $data = $this->post();

        $this->db->SELECT('Id_EstudiantePrueba, Num_Intento, Nota');
        $this->db->from('estudiante_prueba');
        $this->db->where('Id_Prueba', $data['Id_Prueba']);
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);
        $queryEstudiantePru = $this->db->get();
        $fila = $queryEstudiantePru->row();

        
        $this->db->SELECT('preg.*, resp.Id_Respuesta, resp.Respuesta, resp.Valor as ValorResp');
        $this->db->from('prueba_temas prutm');
        $this->db->where('prutm.Id_Prueba', $data['Id_Prueba']);
        $this->db->join('tema tm', 'prutm.Id_Tema = tm.Id_Tema');
        $this->db->join('tema_preguntas tmpre', 'tm.Id_Tema = tmpre.Id_Tema');
        $this->db->join('preguntas preg', 'tmpre.Id_Pregunta = preg.Id_Pregunta');
        $this->db->join('respuesta_preguntas respre', 'preg.Id_Pregunta = respre.Id_Pregunta');
        $this->db->join('respuestas resp', 'respre.Id_Respuesta = resp.Id_Respuesta');
        $queryPreguntas = $this->db->get();

        $this->db->SELECT('Id_Pregunta, Id_Respuesta, Respuesta');
        $this->db->from('prueba_hecha');
        $this->db->where('Id_EstudiantePrueba', $fila->Id_EstudiantePrueba);
        $queryResp = $this->db->get();

        

        if(isset($queryPreguntas) && isset($queryResp)){
            $cantidadFilas = $queryPreguntas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'preguntas' => $queryPreguntas->result_array(),
                    'resp' => $queryResp->result_array(),
                    'Id_EstudiantePrueba' => $fila->Id_EstudiantePrueba,
                    'intento' => $fila->Num_Intento,
                    'notaAnt' => $fila->Nota
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }

        $this->response($respuesta);
    }

    public function buscarPreguntas_post(){
        $data = $this->post();

        $this->db->SELECT('preg.*');
        $this->db->from('tema_preguntas tempre');
        $this->db->where('tempre.Id_Tema', $data['Id_Tema']);
        $this->db->join('preguntas preg', 'tempre.Id_Pregunta = preg.Id_Pregunta');
        $queryPreguntas = $this->db->get();

        if(isset($queryPreguntas)){
            $cantidadFilas = $queryPreguntas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'preguntas' => $queryPreguntas->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarPreguntasTemas_post(){
        $data = $this->post();

        $listado = array();
        foreach($data as $tema){
            $this->db->SELECT('tempre.Id_Tema, preg.*');
            $this->db->from('tema_preguntas tempre');
            $this->db->where('tempre.Id_Tema', $tema['Id_Tema']);
            $this->db->join('preguntas preg', 'tempre.Id_Pregunta = preg.Id_Pregunta');
            $queryPreguntas = $this->db->get();
            if(isset($queryPreguntas)){
                $listado = array_merge($listado, $queryPreguntas->result_array());
            }
        }

        if(sizeof($listado)){           // si el tamanio es 0 no entra
            $respuesta = array(
                'encontrado' => true,
                'preguntas' => $listado
            );
        }else{
            $respuesta = array(
                'encontrado' => false
            );
        }
        $this->response($respuesta);
    }

    public function buscarRespuestas_post(){
        $data = $this->post();

        $this->db->SELECT('resp.*');
        $this->db->from('respuesta_preguntas respre');
        $this->db->where('respre.Id_Pregunta', $data['Id_Pregunta']);
        $this->db->join('respuestas resp', 'respre.Id_Respuesta = resp.Id_Respuesta');
        $queryRespuestas = $this->db->get();

        if(isset($queryRespuestas)){
            $cantidadFilas = $queryRespuestas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'respuestas' => $queryRespuestas->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }


    /**TODOS LOS ELIMINAR DESDE AQUÍ**/

    public function eliminarPrueba_post(){
        $data = $this->post();
        $this->db->SELECT('Id_Estudiante');
        $this->db->from('estudiante_prueba');
        $this->db->where('Id_Prueba', $data['Id_Prueba']);
        $queryPrueba = $this->db->get();


        if(isset($queryPrueba)){
            $cantidadFilas = $queryPrueba->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'Esta Prueba ya la ha realizado al menos un Estudiante'
                );
            }else{
                $this->db->SELECT('Id_CursoPrueba');                  // obtenemos el Id de curso_prueba de la prueba
                $this->db->from('curso_prueba');
                $this->db->where('Id_Prueba', $data['Id_Prueba']);
                $queryCursoPrueba = $this->db->get();
                if(isset($queryCursoPrueba)){
                    $cantFilasCurPrue = $queryCursoPrueba->num_rows();
                    if($cantFilasCurPrue > 0){          // si hay registros en cursopruebapregunta eliminamos
                        $resultCurPrue = $queryCursoPrueba->result_array();
                        $this->db->where('Id_CursoPrueba', $resultCurPrue[0]['Id_CursoPrueba']); // delete en tabla cursopruebapregunta
                        $this->db->delete('cursopruebapregunta');
                    }
                    $this->db->where('Id_Prueba', $data['Id_Prueba']);  // delete en tabla curso_prueba
                    $this->db->delete('curso_prueba');

                    $this->db->SELECT('Id_Tema');                  // obtenemos todos los temas de la prueba
                    $this->db->from('prueba_temas');
                    $this->db->where('Id_Prueba', $data['Id_Prueba']);
                    $queryTemas = $this->db->get();
    
                    if(isset($queryTemas)){
                        $this->db->where('Id_Prueba', $data['Id_Prueba']);  // delete en tabla prueba_temas
                        $this->db->delete('prueba_temas');
                        $cantFilasTemas = $queryTemas->num_rows();
    
                        if($cantFilasTemas > 0){
                            $temas = $queryTemas->result_array();
                            for ($iTema = 0; $iTema < $cantFilasTemas; $iTema++){
                                // Verificamos que los temas de esa Prueba no se usen en otras pruebas
                                $this->db->SELECT('Id_Prueba');                  // buscamos si el tema a eliminar sigue constando en la tabla prueba_temas 
                                $this->db->from('prueba_temas');
                                $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);
                                $queryTemasUsados = $this->db->get();
    
                                if (isset($queryTemasUsados)){
                                    $cantFilasTemasUsados = $queryTemasUsados->num_rows();
                                    if($cantFilasTemasUsados == 0){          // si el tema ya no se usa lo eliminamos
                                        $this->db->SELECT('Id_Pregunta');                  // obtenemos todas las preguntas del tema
                                        $this->db->from('tema_preguntas');
                                        $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);
                                        $queryPreguntas = $this->db->get();
            
                                        if(isset($queryPreguntas)){
                                            $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);  // delete en tabla tema_preguntas
                                            $this->db->delete('tema_preguntas');
                                            $cantidadFilasPreg = $queryPreguntas->num_rows();
            
                                            if($cantidadFilasPreg > 0){
                                                $preguntas = $queryPreguntas->result_array();
                                                for ($iPreg = 0; $iPreg < $cantidadFilasPreg; $iPreg++){
                                                    $this->db->SELECT('Id_Respuesta');                  // obtenemos todas las respuestas de esa pregunta
                                                    $this->db->from('respuesta_preguntas');
                                                    $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);
                                                    $queryRespuesta = $this->db->get();
                                                    
                                                    if(isset($queryRespuesta)){
                                                        $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);  // delete en tabla respuesta_preguntas
                                                        $this->db->delete('respuesta_preguntas');
                                                        $cantidadFilasResp = $queryRespuesta->num_rows();
            
                                                        if($cantidadFilasResp > 0){
                                                            $resptas = $queryRespuesta->result_array();
                                                            for ($iResp = 0; $iResp < $cantidadFilasResp; $iResp++){
                                                                $this->db->where('Id_Respuesta', $resptas[$iResp]['Id_Respuesta']);  // eliminamos las respuestas de la pregunta
                                                                $this->db->delete('respuestas');
                                                            }
                                                        }
                                                        $this->db->SELECT('Imagen');                    // Buscamos la imagen de esa pregunta si tubiera
                                                        $this->db->from('preguntas');
                                                        $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);
                                                        $queryImagen = $this->db->get();

                                                        if(isset($queryImagen)){
                                                            $imagen = $queryImagen->result_array();
                                                            $imgAnterior = $imagen[0]['Imagen'];        // obtenemos el nombre de la imagen, si no tiene devuelve null
                                                            if ($imgAnterior != null){                  // si existe una imagen la eliminamos de la carpeta
                                                                $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/preguntas/" . $imgAnterior;
                                                                Unlink($ruta);
                                                            }
                                                        }
                                                        $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);  // delete en tabla preguntas
                                                        $this->db->delete('preguntas');
                                                    }
                                                }
                                            }
                                            $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);  // delete en tabla tema
                                            $this->db->delete('tema');
                                        }
                                    }
                                }
                            }
                        }
                        $this->db->where('Id_Prueba', $data['Id_Prueba']);  // delete en tabla prueba
                        $this->db->delete('prueba');
        
                        $respuesta = array(
                            'error' => false,
                            'mensaje' => 'Prueba eliminada Correctamente'
                        );
                    }
                }
            }
        }
        $this->response($respuesta);
    }

    public function eliminarTema_post(){
        $data = $this->post();
        $this->db->SELECT('Id_Prueba');
        $this->db->from('prueba_temas');
        $this->db->where('Id_Tema', $data['Id_Tema']);
        $queryPrueba = $this->db->get();


        if(isset($queryPrueba)){
            $cantidadFilas = $queryPrueba->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'Este Tema está siendo utilizado en una Prueba Generada'
                );
            }else{
                $this->db->SELECT('tempreg.Id_Pregunta, preg.Imagen');                  // obtenemos todas las preguntas del tema
                $this->db->from('tema_preguntas tempreg');
                $this->db->where('tempreg.Id_Tema', $data['Id_Tema']);
                $this->db->join('preguntas preg', 'tempreg.Id_Pregunta = preg.Id_Pregunta');
                $queryPreguntas = $this->db->get();

                if(isset($queryPreguntas)){
                    $this->db->where('Id_Tema', $data['Id_Tema']);  // delete en tabla tema_preguntas
                    $this->db->delete('tema_preguntas');
                    $cantidadFilasPreg = $queryPreguntas->num_rows();

                    if($cantidadFilasPreg > 0){
                        $preguntas = $queryPreguntas->result_array();
                        for ($iPreg = 0; $iPreg < $cantidadFilasPreg; $iPreg++){
                            $this->db->SELECT('Id_Respuesta');                  // obtenemos todas las respuestas de esa pregunta
                            $this->db->from('respuesta_preguntas');
                            $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);
                            $queryRespuesta = $this->db->get();
                            
                            if(isset($queryRespuesta)){
                                $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);  // delete en tabla respuesta_preguntas
                                $this->db->delete('respuesta_preguntas');
                                $cantidadFilasResp = $queryRespuesta->num_rows();
                                if($cantidadFilasResp > 0){
                                    $resptas = $queryRespuesta->result_array();
                                    for ($i = 0; $i < $cantidadFilasResp; $i++){
                                        $this->db->where('Id_Respuesta', $resptas[$i]['Id_Respuesta']);  // eliminamos las respuestas de la pregunta
                                        $this->db->delete('respuestas');
                                    }
                                }
                                $this->db->where('Id_Pregunta', $preguntas[$iPreg]['Id_Pregunta']);  // delete en tabla preguntas
                                $this->db->delete('preguntas');

                                if ($preguntas[$iPreg]['Imagen'] != null){           // si la pregunta tiene imagen la eliminamos de la carpeta
                                    $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/preguntas/" . $preguntas[$iPreg]['Imagen'];
                                    Unlink($ruta);
                                }
                            }

                        }
                    }
                    $this->db->where('Id_Tema', $data['Id_Tema']);  // delete en tabla tema
                    $this->db->delete('tema');
                }

                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Tema eliminado Correctamente'
                );
            }
        }
        $this->response($respuesta);
    }

    public function eliminarPregunta_post(){
        $data = $this->post();
        $this->db->SELECT('Id_CursoPrueba');                    // Buscamos si la pregunta se encuentra en una prueba generada
        $this->db->from('cursopruebapregunta');
        $this->db->where('Id_Pregunta', $data['Id_Pregunta']);
        $queryPregunta = $this->db->get();
        if(isset($queryPregunta)){
            $cantidadFilas = $queryPregunta->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'Esta Pregunta está siendo utilizada en una Prueba Generada'
                );
            }else{
                $this->db->where('Id_Pregunta', $data['Id_Pregunta']);  // delete en tabla tema_preguntas
                $this->db->delete('tema_preguntas');

                $this->db->SELECT('Id_Respuesta');                  // obtenemos todas las respuestas de esa pregunta
                $this->db->from('respuesta_preguntas');
                $this->db->where('Id_Pregunta', $data['Id_Pregunta']);
                $queryRespuesta = $this->db->get();

                $this->db->where('Id_Pregunta', $data['Id_Pregunta']);  // delete en tabla respuesta_preguntas
                $this->db->delete('respuesta_preguntas');

                if(isset($queryRespuesta)){
                    $cantidadFilas = $queryRespuesta->num_rows();
                    if($cantidadFilas > 0){
                        $resptas = $queryRespuesta->result_array();
                        for ($i = 0; $i < $cantidadFilas; $i++){
                            $this->db->where('Id_Respuesta', $resptas[$i]['Id_Respuesta']);  // eliminamos las respuestas de la pregunta
                            $this->db->delete('respuestas');
                        }
                    }
                }

                $this->db->where('Id_Pregunta', $data['Id_Pregunta']);  // delete en tabla preguntas
                $this->db->delete('preguntas');

                if ($data['Imagen'] != null){           // si la pregunta tiene imagen la eliminamos de la carpeta
                    $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/preguntas/" . $data['Imagen'];
                    Unlink($ruta);
                }

                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Pregunta eliminada Correctamente'
                );
            }
        }
        $this->response($respuesta);
    }

    public function eliminarRespuesta_post(){
        $data = $this->post();
        $this->db->SELECT('*');
        $this->db->from('prueba_hecha');
        $this->db->where('Id_Respuesta', $data['Id_Respuesta']);
        $queryRespuesta = $this->db->get();
        if(isset($queryRespuesta)){
            $cantidadFilas = $queryRespuesta->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'Esta Respuesta está siendo utilizada en una prueba ya Realizada'
                );
            }else{
                $this->db->where('Id_Respuesta', $data['Id_Respuesta']);  // tabla respuesta_preguntas
                $this->db->delete('respuesta_preguntas');
                $this->db->where('Id_Respuesta', $data['Id_Respuesta']);  // tabla respuestas
                $this->db->delete('respuestas');
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Respuesta eliminada Correctamente'
                );
            }
        }
        $this->response($respuesta);
    }

    /**TODOS LOS ACTUALIZAR DESDE AQUÍ**/

}
