<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class Ubicacionservice extends REST_Controller
{
    public function __construct()
    {

        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");


        parent::__construct();
        $this->load->database();
    }

    public function index_get()
    {
        //http://localhost:8888/restpracticas/index.php/indexservice/obtenerindex
        //http://jsonparseronline.com/
        
        $respuesta = 'este es mi index';
        $this->response($respuesta);
    }

    public function obtenerubicacion_get()
    {
        $queryUbicacion = $this->db->query("SELECT * FROM `tubicacion`");
        $queryUbicacionTransporteArribo = $this->db->query("SELECT * FROM `ttransportearribo`");
        $queryUbicacionTurismo = $this->db->query("SELECT * FROM `tturismo`");

        $respuesta = array(
            'error' => false,
            'ubicacion' => $queryUbicacion->result_array(),
            'ubicaciontransportearribo' => $queryUbicacionTransporteArribo->result_array(),
            'ubicacionturismo' => $queryUbicacionTurismo->result_array()
        );

        $this->response($respuesta);
    }

    public function actualizarubicacion_post(){
        $data = $this->post();
        $titulo1 = $data['titulo1'];
        $tituloriobamba = $data['tituloriobamba'];
        $subtituloriobamba = $data['subtituloriobamba'];
        $titulocomollegar = $data['titulocomollegar'];
        $tituloespoch = $data['tituloespoch'];
        $fotoespoch = $data['fotoespoch'];
        $titulorio = $data['titulorio'];
        $fotorio = $data['fotorio'];
        $tituloavion = $data['tituloavion'];
        $titulobus = $data['titulobus'];
        $titulotaxi = $data['titulotaxi'];
        $tituloarribo = $data['tituloarribo'];
        $subtituloarribo = $data['subtituloarribo'];
        $tituloescuelasuperior = $data['tituloescuelasuperior'];
        $subtituloescuelasuperior = $data['subtituloescuelasuperior'];
        $tituloturismo = $data['tituloturismo'];
        $subtituloturismo = $data['subtituloturismo'];
        
        $datosFechas = array(
            'titulo1' => $titulo1,
            'tituloriobamba' => $tituloriobamba,
            'subtituloriobamba' => $subtituloriobamba, 
            'titulocomollegar' => $titulocomollegar,
            'tituloespoch' => $tituloespoch,
            'fotoespoch' => $fotoespoch,
            'titulorio' => $titulorio,
            'fotorio' => $fotorio,
            'tituloavion' => $tituloavion,
            'titulobus' => $titulobus,
            'titulotaxi' => $titulotaxi,
            'tituloarribo' => $tituloarribo,
            'subtituloarribo' => $subtituloarribo, 
            'tituloescuelasuperior' => $tituloescuelasuperior,
            'subtituloescuelasuperior' => $subtituloescuelasuperior,
            'tituloturismo' => $tituloturismo,
            'subtituloturismo' => $subtituloturismo
        );
        $this ->db->update('tubicacion', $datosFechas);

        $respuesta = array(
            'error' => false
        );
        
        $this->response($respuesta);
    }
}
