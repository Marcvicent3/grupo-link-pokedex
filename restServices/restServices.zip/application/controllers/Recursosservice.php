<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class Recursosservice extends REST_Controller
{
    public function __construct()
    {

        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");


        parent::__construct();
        $this->load->database();
    }

    public function index_get()
    {
        //http://localhost:8888/restpracticas/index.php/indexservice/obtenerindex
        //http://jsonparseronline.com/
        
        $respuesta = 'este es mi index';
        $this->response($respuesta);
    }

    public function obtenerrecursos_get()
    {
        $queryRecursos = $this->db->query("SELECT * FROM `trecursos`");

        $respuesta = array(
            'error' => false,
            'recursos' => $queryRecursos->result_array()
        );

        $this->response($respuesta);
    }

    public function actualizarrecursos_post(){
        $data = $this->post();
        $titulo1 = $data['titulo1'];
        $tituloplantilla = $data['tituloplantilla'];
        $enlace1 = $data['enlace1'];
        $tituloeasychair = $data['tituloeasychair'];
        $enlace2 = $data['enlace2'];
        $titulowiki = $data['titulowiki'];
        $enlace3 = $data['enlace3'];
        $titulocartel = $data['titulocartel'];
        $enlace4 = $data['enlace4'];
        $enlaceregistro = $data['enlaceregistro'];
        

        $datosFechas = array(
            'titulo1' => $titulo1,
            'tituloplantilla' => $tituloplantilla,
            'enlace1' => $enlace1,
            'tituloeasychair' => $tituloeasychair,
            'enlace2' => $enlace2,
            'titulowiki' => $titulowiki,
            'enlace3' => $enlace3,
            'titulocartel' => $titulocartel,
            'enlace4' => $enlace4,
            'enlaceregistro' => $enlaceregistro
        );
        $this ->db->update('trecursos', $datosFechas);

        $respuesta = array(
            'error' => false
        );
        
        $this->response($respuesta);
    }
}
