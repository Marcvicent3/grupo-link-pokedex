<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class CursoService extends REST_Controller
{
    public function __construct(){
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");
        parent::__construct();
        $this->load->database();
    }

    public function index_get(){
        $queryCurso = $this->db->query("SELECT * FROM `curso`");

        $respuesta = array(
            'error' => false,
            'curso' => $queryCurso->result_array()
        );
        $this->response($respuesta);
    }

    public function obtenerCurso_get(){
        $queryCurso = $this->db->query("SELECT * FROM `curso`");

        if (isset($queryCurso)){
            $respuesta = array(
                'error' => false,
                'curso' => $queryCurso->result_array()
            );
            $this->response($respuesta);
        }
    }

    public function obtenerBodega_get(){
        $queryBodega = $this->db->query("SELECT * FROM `bodega`");

        if (isset($queryBodega)){
            $respuesta = array(
                'error' => false,
                'bodega' => $queryBodega->result_array()
            );
            $this->response($respuesta);
        }
        $this->response($respuesta);
    }

    public function obtenerArticulosFactura_get(){
        $queryArticulosFactura = $this->db->query("SELECT * FROM `articulos_factura` ORDER BY CodigoArt");

        if (isset($queryArticulosFactura)){
            $respuesta = array(
                'error' => false,
                'articulos_factura' => $queryArticulosFactura->result_array()
            );
            $this->response($respuesta);
        }
    }

    public function obtenerFacturaParametro_post(){
        $data = $this->post();
        $valBuscar = $data['valor'];
        
        $queryFactura = $this->db->query("SELECT * FROM `factura` WHERE 'Id_Factura' = $valBuscar ORDER BY NumFactura");
        
        if(isset($queryFactura)){
            $cantidadFilas = $queryFactura->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => false,
                    'factura' => $queryFactura->result_array(),
                );
            }else{
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'No existen coincidencias',
                );
            }
        }
        $this->response($respuesta);
    }

    // TODOS LOS INGRESAR EN ESTA SECCIÓN

    public function ingresarCurso_post(){
        $data = $this->post();
        $id = null;
        $datos = array(
            'Grado' => $data['Grado'],
            'Paralelo' => $data['Paralelo']
        );

        if(isset($data['Id_Curso'])){
            $id = $data['Id_Curso'];
        }

        if (($id == null)) {
            $this->db->insert('curso', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'curso se guardo correctamente',
                'id_nuevo' => $nuevoId
            );
            $this->response($respuesta);
        } else {
            $this->db->where('Id_Curso', $id);
            $this->db->update('curso', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'El curso se actualizo correctamente'
                );
            $this->response($respuesta);
        }
    }

    public function ingresarArticulosFactura_post(){
        $data = $this->post();
        foreach($data as $posicion=>$articulo){
            if($articulo['CodigoArt'] != null && $articulo['CodigoArt'] != ''){
                $datos = array(
                    'Id_Factura' => $articulo['Id_Factura'],
                    'Id_Articulo' => $articulo['Id_Articulo'],
                    'CodigoArt' => $articulo['CodigoArt'],
                    'NombreArt' => $articulo['NombreArt'],
                    'Precio' => $articulo['Precio'],
                    'IVA' => $articulo['IVA'],
                    'Descuento' => $articulo['Descuento'],
                    'Cantidad' => $articulo['Cantidad'],
                    'Id_Bodega' => $articulo['Id_Bodega']
                );
                $this->db->insert('articulos_factura', $datos);
            }
        }
        $respuesta = array(
            'error' => false,
            'mensaje' => 'Articulos Factura se actualizo correctamente'
        );
        $this->response($respuesta);
    }


    /**TODOS LOS BUSCAR DESDE AQUÍ **/
    public function buscarFactura_post(){
        $data = $this->post();
        $valor = $data['valor'];

        $this->db->SELECT('*');
        $this->db->from('factura');
        $this->db->where('NumFactura', $valor);
        
        $queryFactura = $this->db->get();

        if(isset($queryFactura)){
            $cantidadFilas = $queryFactura->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => false,
                    'factura' => $queryFactura->result_array(),
                );
            }else{
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'No existen coincidencias de factura',
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarArticulosFactura_post(){
        $data = $this->post();
        $valor = $data['valor'];

        $this->db->SELECT('*');
        $this->db->from('articulos_factura');
        $this->db->where('Id_Factura', $valor);

        $queryArticulosFactura = $this->db->get();

        if(isset($queryArticulosFactura)){
            $cantidadFilas = $queryArticulosFactura->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => false,
                    'articulos_factura' => $queryArticulosFactura->result_array(),
                );
            }else{
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'No existen coincidencias de articulos',
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarBodega_post(){
        $data = $this->post();
        $valor = $data['valor'];
        $parametro = $data['parametro'];

        $this->db->SELECT('*');
        $this->db->from('bodega');
        
        if($parametro == 'Id_Bodega'){
            $this->db->where($parametro, $valor);
        }else{
            $this->db->like($parametro, $valor, 'both');
        }
        $queryBodega = $this->db->get();

        if(isset($queryBodega)){
            $cantidadFilas = $queryBodega->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => false,
                    'bodega' => $queryBodega->result_array(),
                );
            }else{
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'No existen coincidencias de bodega',
                );
            }
        }
        $this->response($respuesta);
    }

    /* TODOS LOS ELIMINAR DESDE ESTE PUNTO*/
    public function eliminarFactura_post(){
        $data = $this->post();
        $this->db->delete('factura', array('Id_Factura' => $data['Id_Factura']));
        
        $respuesta = array(
            'error' => false,
            'mensaje' => 'La Factura se eliminó correctamente'
        );
        $this->response($respuesta);
    }


    public function eliminarArticulosFactura_post(){
        $data = $this->post();
        $this->db->delete('articulos_factura', array('Id_Factura' => $data['Id_Factura']));
        
        $respuesta = array(
            'error' => false,
            'mensaje' => 'Articulos de Factura se eliminaron correctamente'
        );
        $this->response($respuesta);
    }

}
