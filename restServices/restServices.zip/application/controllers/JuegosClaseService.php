<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class JuegosClaseService extends REST_Controller
{
    public function __construct(){
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");
        parent::__construct();
        $this->load->database();
    }

    public function index_get(){
        $queryJuegosClase = $this->db->query("SELECT * FROM `juegos_clase`");
        $queryReglasJuego = $this->db->query("SELECT * FROM `reglas_juego`");

        $respuesta = array(
            'error' => false,
            'juegos_clase' => $queryJuegosClase->result_array(),
            'reglas_juego' => $queryReglasJuego->result_array(),
        );
        $this->response($respuesta);
    }
    public function obtenerJuegosClase_get(){
        $queryJuegosClase = $this->db->query("SELECT * FROM `juegos_clase`");

        $respuesta = array(
            'error' => false,
            'juegos_clase' => $queryJuegosClase->result_array(),
        );
        $this->response($respuesta);
    }

    public function obtenerJuegosReglaClase_get(){
        $this->db->SELECT('juegos.*, regjue.Descripcion as NombreRegla');
        $this->db->FROM('juegos_clase juegos');
        $this->db->JOIN('juego_regla juereg', 'juegos.Id_Juego = juereg.Id_Juego');
        $this->db->JOIN('reglas_juego regjue', 'juereg.Id_Regla = regjue.Id_Regla');
        $queryJuegosClase = $this->db->get();


        if (isset($queryJuegosClase)){
            $respuesta = array(
                'error' => false,
                'juegos_regla' => $queryJuegosClase->result_array()
            );
            $this->response($respuesta);
        }
    }


    // TODOS LOS INGRESAR EN ESTA SECCIÓN

    public function ingresarJuegosClase_post(){
        $data = $this->post();
        $id = $data['Id_Juego'];
        $datos = array(
            'Nombre' => $data['Nombre'],
            'Descripcion' => $data['Descripcion']
        );

        if (($id == null)) {
            $this->db->insert('juegos_clase', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Juegos Clase se guardo correctamente',
                'id_nuevo' => $nuevoId
            );
            $this->response($respuesta);
        } else {
            $this->db->where('Id_Juego', $id);
            $this->db->update('juegos_clase', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'El juego clase se actualizo correctamente'
                );
            $this->response($respuesta);
        }
    }

    public function ingresarReglasJuego_post(){
        $data = $this->post();
        $regla = $data['Regla'];
        $juego = $data['Juego'];
        $id = $regla['Id_Regla'];

        $datos = [
            'Descripcion' => $regla['Descripcion']
        ];

        if (($id == null)) {
            $this->db->insert('reglas_juego', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Reglas Juego se guardo correctamente',
                'id_nuevo' => $nuevoId
            );

            $dataJuegoRegla = [
                'Id_Juego' => $juego,
                'Id_Regla' => $nuevoId
            ];

            $this->db->insert('juego_regla', $dataJuegoRegla);
        } else {
            $this->db->where('Id_Regla', $id);
            $this->db->update('reglas_juego', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Reglas Juego se actualizo correctamente'
                );
            }
        $this->response($respuesta);
    }

    /* TODOS LOS BUSCAR DESDE ESTE PUNTO */

    
    public function buscarReglasJuego_post(){
        $data = $this->post();        
        $this->db->SELECT('regjue.*');
        $this->db->FROM('juego_regla juereg');
        $this->db->WHERE('juereg.Id_Juego', $data['Id_Juego']);
        $this->db->JOIN('reglas_juego regjue', 'juereg.Id_Regla = regjue.Id_Regla');

        $queryReglasJuego = $this->db->get();
        if (isset($queryReglasJuego)){
            $cantidadFilas = $queryReglasJuego->num_rows();
            if ($cantidadFilas > 0){
                $respuesta = array(
                    'error' => false,
                    'reglas_juego' => $queryReglasJuego->result_array()
                );
            }else{
                $respuesta = array(
                    'error' => true
                );
            }
            $this->response($respuesta);
        }
    }

    /* TODOS LOS ELIMINAR DESDE ESTE PUNTO*/
    public function eliminarJuegosClase_post(){
        $data = $this->post();

        $this->db->SELECT('Id_Regla');                  // obtenemos todas las reglas de ese juego
        $this->db->from('juego_regla');
        $this->db->where('Id_Juego', $data['Id_Juego']);
        $queryRegla = $this->db->get();

        
        if(isset($queryRegla)){
            $this->db->where('Id_Juego', $data['Id_Juego']);  // delete en tabla juego_regla
            $this->db->delete('juego_regla');
            $cantidadFilas = $queryRegla->num_rows();
            if($cantidadFilas > 0){
                $resptas = $queryRegla->result_array();
                for ($i = 0; $i < $cantidadFilas; $i++){
                    $this->db->where('Id_Regla', $resptas[$i]['Id_Regla']);  // eliminamos las reglas del juego
                    $this->db->delete('reglas_juego');
                }
            }
            
                    $this->db->where('Id_Juego', $data['Id_Juego']);  // delete en tabla juegos_clase
                    $this->db->delete('juegos_clase');
        }

        if ($data['Imagen'] != null){           // si la pregunta tiene imagen la eliminamos de la carpeta
            $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/juegos/" . $data['Imagen'];
            Unlink($ruta);
        }

        $respuesta = array(
            'error' => false,
            'mensaje' => 'Juego eliminado Correctamente'
        );

        $this->response($respuesta);
    }
    
    public function eliminarReglasJuego_post(){
        $data = $this->post();

        $this->db->where('Id_Regla', $data['Id_Regla']);  // tabla juego_regla
        $this->db->delete('juego_regla');
        $this->db->where('Id_Regla', $data['Id_Regla']);  // tabla reglas_juego
        $this->db->delete('reglas_juego');
        $respuesta = array(
            'error' => false,
            'mensaje' => 'Regla eliminada Correctamente'
        );
        $this->response($respuesta);
    }
    
}
