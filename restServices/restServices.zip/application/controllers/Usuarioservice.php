<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class Usuarioservice extends REST_Controller
{
    public function __construct()
    {
  
      header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
      header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
      header("Access-Control-Allow-Origin: *");
      parent::__construct();
      $this->load->database();
    }

    public function index()
    {
        echo "Por defecto";
    }

    public function obtenerusuarios_get()
    {
        $queryUsuarios = $this->db->query("SELECT * FROM `usuarios`");

        $respuesta = array(
            'error' => false,
            'usuarios' => $queryUsuarios->result_array()
        );

        $this->response($respuesta);
    }

    public function actualizarusuarios_post(){
        $data = $this->post();
        $nombres = $data['nombres'];
        $usuario = $data['usuario'];
        $correo = $data['correo'];
        $contrasena = $data['contrasena'];
        $foto = $data['foto'];

        $datosFechas = array(
            'nombres' => $nombres,
            'usuario' => $usuario,
            'correo' => $correo,
            'contrasena' => $contrasena,
            'foto' => $foto
        );
        $this ->db->update('usuarios', $datosFechas);

        $respuesta = array(
            'error' => false
        );
        
        $this->response($respuesta);
    }
}
