<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class WorksheetService extends REST_Controller
{
    public function __construct(){
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");
        parent::__construct();
        $this->load->database();
    }


    public function index_get(){
        $respuesta = 'WorksheetService-index_get()';
        $this->response($respuesta);
    }

    public function obtenerWorksheets_get(){
        $this->db->SELECT('work.*, cur.Grado, cur.Paralelo');
        $this->db->from('worksheets work');
        $this->db->join('curso_ws curwork', 'work.Id_Ws = curwork.Id_Ws');
        $this->db->join('curso cur', 'curwork.Id_Curso = cur.Id_Curso');
        $this->db->order_by('cur.Paralelo ASC, work.Titulo ASC');
        $queryWorksheets = $this->db->get();

        if (isset($queryWorksheets)){
            $cantidadFilas = $queryWorksheets->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'worksheets' => $queryWorksheets->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }

            $this->response($respuesta);
        }
    }

    public function obtenerTemas_get(){
        $this->db->SELECT('*');
        $this->db->from('temaws');
        $this->db->order_by('Tema ASC');
        $queryTemas = $this->db->get();

        if (isset($queryTemas)){
            $cantidadFilas = $queryTemas->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'temas' => $queryTemas->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }

            $this->response($respuesta);
        }
    }

    // TODOS LOS INGRESAR EN ESTA SECCIÓN

    public function ingresarWorksheet_post(){
        $data = $this->post();

        $worksheet = $data['Worksheet'];
        $enunciados = $data['Enunciados'];
        $temas = $data['Temas'];

        $datosWorksheet = [
            'Titulo' => $worksheet['Titulo'],
            'Password' => $worksheet['Password'],
            'Fecha_Inicio' => $worksheet['Fecha_Inicio'],
            'Fecha_Fin' => $worksheet['Fecha_Fin'],
            'Intentos' => $worksheet['Intentos'],
            'NotaTotal' => $worksheet['NotaTotal'],
            'NotaMin' => $worksheet['NotaMin'],
            'Observacion' => $worksheet['Observacion']
        ];
        if ($worksheet['Id_Ws'] == null){
            $this->db->insert('worksheets', $datosWorksheet);             // ingresamos los datos del nuevo worksheet
            $nuevoId = $this->db->insert_id();

            $datosCursoWorksheet = [
                'Id_Curso' => $data['Curso'],
                'Id_Ws' => $nuevoId
            ];
            $this->db->insert('curso_ws', $datosCursoWorksheet);         // ingresamos los datos en curso_ws
            $nuevoIdCurWork = $this->db->insert_id();

            foreach ($enunciados as $enun){              // ingresamos todos los enunciados del worksheet
                $datosCursoEnuOpc = [
                    'Id_CursoWs' => $nuevoIdCurWork,
                    'Id_Enunciado' => $enun['Id_Enunciado']
                ];
                $this->db->insert('cursoenunciadoopcion', $datosCursoEnuOpc);
            }

            foreach ($temas as $tema){          // ingresamos todos los temas del worksheet
                $datosWorksheetTema = [
                    'Id_Ws' => $nuevoId,
                    'Id_Tema' => $tema['Id_Tema']
                ];
                $this->db->insert('worksheet_temasws', $datosWorksheetTema);
            }

            $respuesta = array(
                'error' => false,
                'mensaje' => 'Worksheet ingresado Correctamente'
            );
        }else{
            $this->db->where('Id_Ws', $worksheet['Id_Ws']);          // actualizamos los datos del worksheet
            $this->db->update('worksheets', $datosWorksheet);

            $this->db->SELECT('Id_CursoWs');                       // Buscamos el Id_CursoWs para acceder a los enunciados
            $this->db->from('curso_ws');
            $this->db->where('Id_Ws', $worksheet['Id_Ws']);
            $queryCursoWorksheet = $this->db->get();
            $resultCursoWorksheet =  $queryCursoWorksheet->result_array();

            $datosCursoWs = [
                'Id_Curso' => $data['Curso']
            ];
            $this->db->where('Id_CursoWs', $resultCursoWorksheet[0]['Id_CursoWs']);          // actualizamos el curso por si se cambio
            $this->db->update('curso_ws', $datosCursoWs);

            $this->db->where('Id_CursoWs', $resultCursoWorksheet[0]['Id_CursoWs']);    // borramos todas las worksheets de esa worksheets
            $this->db->delete('cursoenunciadoopcion');

            foreach ($enunciados as $enun){              // ingresamos nuevamente todas las worksheets de la worksheets
                $datosCursoEnuOpc = [
                    'Id_CursoWs' => $resultCursoWorksheet[0]['Id_CursoWs'],
                    'Id_Enunciado' => $enun['Id_Enunciado']
                ];
                $this->db->insert('cursoenunciadoopcion', $datosCursoEnuOpc);
            }

            $this->db->where('Id_Ws', $worksheet['Id_Ws']);    // borramos todas los temas de esa worksheets
            $this->db->delete('worksheet_temasws');   

            foreach ($temas as $tema){          // ingresamos nuevamente todos los temas de la worksheets
                $datosWorksheetTema = [
                    'Id_Ws' => $worksheet['Id_Ws'],
                    'Id_Tema' => $tema['Id_Tema']
                ];
                $this->db->insert('worksheet_temasws', $datosWorksheetTema);
            }

            $respuesta = array(
                'error' => false,
                'mensaje' => 'Worksheets actualizada Correctamente'
            );
        }

        $this->response($respuesta);
    }

    public function ingresarTema_post(){
        $data = $this->post();
        $id = $data['Id_Tema'];
        $datos = array(
            'Tema' => $data['Tema'],
        );

        if (($id == null)) {
            $this->db->insert('temaws', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Tema guardado correctamente',
                'id_nuevo' => $nuevoId
            );
        } else {
            $this->db->where('Id_Tema', $id);
            $this->db->update('temaws', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Tema actualizado correctamente'
                );
        }
        $this->response($respuesta);
    }

    public function ingresarEnunciado_post(){
        $data = $this->post();
        $id = $data['Id_Enunciado'];
        $datos = array(
            'Encabezado' => $data['Encabezado'],
            'Tipo' => $data['Tipo'],
            'Valor' => $data['Valor']
        );

        if (($id == null)) {
            $this->db->insert('enunciado_ws', $datos);
            $nuevoId = $this->db->insert_id();

            $datosWorkEnun = array(
                'Id_Tema' => $data['Id_Tema'],
                'Id_Enunciado' => $nuevoId
            );
            $this->db->insert('tema_enunciados', $datosWorkEnun);

            $respuesta = array(
                'error' => false,
                'mensaje' => 'Worksheet se guardó correctamente',
                'id_nuevo' => $nuevoId
            );
        } else {
            $this->db->where('Id_Enunciado', $id);
            $this->db->update('enunciado_ws', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'La worksheet se actualizó correctamente'
                );
        }
        $this->response($respuesta);
    }

    public function ingresarOpciones_post(){
        $data = $this->post();
        if ($data['Tipo'] != 'MC'){
            $opcion = $data['Opcion'];
            $id = $opcion['Id_Opcion'];
            $datos = array(
                'Opcion' => $opcion['Opcion'],
                'Valor' => $opcion['Valor']
            );
    
            if (($id == null)) {
                $this->db->insert('opciones_ws', $datos);
                $nuevoId = $this->db->insert_id();
    
                $datosEnunOpc = array(
                    'Id_Enunciado' => $opcion['Id_Enunciado'],
                    'Id_Opcion' => $nuevoId
                );
                $this->db->insert('enunciado_opcion', $datosEnunOpc);
    
                $respuestaOpc = array(
                    'error' => false,
                    'mensaje' => 'Opcion se guardó correctamente',
                );
            } else {
                $this->db->where('Id_Opcion', $id);
                $this->db->update('opciones_ws', $datos);
                    $respuestaOpc = array(
                        'error' => false,
                        'mensaje' => 'La opcion se actualizó correctamente'
                    );
            }
        }else{
            $opcion = $data['Opcion'];
            foreach($opcion as $opc){
                if ($opc['Opcion'] != null || $opc['Opcion'] != ""){
                    $id = $opc['Id_Opcion'];
                    $datos = array(
                        'Opcion' => $opc['Opcion'],
                        'Valor' => $opc['Valor']
                    );
            
                    if (($id == null)) {
                        $this->db->insert('opciones_ws', $datos);
                        $nuevoId = $this->db->insert_id();
            
                        $datosEnunOpc = array(
                            'Id_Enunciado' => $opc['Id_Enunciado'],
                            'Id_Opcion' => $nuevoId
                        );
                        $this->db->insert('enunciado_opcion', $datosEnunOpc);
                    } else {
                        $this->db->where('Id_Opcion', $id);
                        $this->db->update('opciones_ws', $datos);
                    }
                }
            }
            $respuestaOpc = array(
                'error' => false,
                'mensaje' => 'Opcion se guardó correctamente',
            );
        }
        $this->response($respuestaOpc);
    }

    public function ingresarEstudianteWs_post(){
        $data = $this->post();

        $id = $data['Id_EstudianteWs'];

        $datos = array(
            'Id_Estudiante' => $data['Id_Estudiante'],
            'Id_Ws' => $data['Id_Ws'],
            'Nota' => $data['Nota'],
            'Num_Intento' => $data['Num_Intento']
        );

        if (($id == null)) {
            $this->db->insert('estudiante_ws', $datos);
            $nuevoId = $this->db->insert_id();

            $respuesta = array(
                'error' => false,
                'id_nuevo' => $nuevoId
            );
        } else {
            $this->db->where('Id_EstudianteWs', $id);
            $this->db->update('estudiante_ws', $datos);

            $respuesta = array(
                'error' => false
            );
        }
        
        $this->response($respuesta);
    }

    public function ingresarEstudianteWsHecho_post(){
        $data = $this->post();
        $WsHecho = $data['WsHecho'];
        
        $datosEstWs = array(
            'Nota' => $data['Nota']
        );

        $this->db->where('Id_EstudianteWs', $data['Id_EstudianteWs']);
        $this->db->update('estudiante_ws', $datosEstWs);

        $this->db->where('Id_EstudianteWs', $data['Id_EstudianteWs']);
        $this->db->delete('worksheet_hecho');

        foreach($WsHecho as $ws){
            $datosWsHecho = array(
                'Id_EstudianteWs' => $data['Id_EstudianteWs'],
                'Id_Enunciado' => $ws['Id_Enunciado'],
                'Id_Opcion' => $ws['Id_Opcion'],
                'Respuesta' => $ws['Respuesta']
            );
            $this->db->insert('worksheet_hecho', $datosWsHecho);
        }

        $respuesta = array(
            'error' => false,
            'mensaje' => 'Worksheet se guardó correctamente'
        );
        
        $this->response($respuesta);
    }


    /**TODOS LOS BUSCAR DESDE AQUÍ **/

    public function buscarDatosWorksheet_post(){
        $data = $this->post();

        $this->db->SELECT('tem.*');                 // Obtenemos los temas del worksheet
        $this->db->from('worksheet_temasws worktem');
        $this->db->where('worktem.Id_Ws', $data['Id_Ws']);
        $this->db->join('temaws tem', 'worktem.Id_Tema = tem.Id_Tema');
        $queryTemas = $this->db->get();
        $cantTemas = $queryTemas->num_rows();

        $listado = array();
        if($cantTemas > 0){                        // Obtenemos todos los enunciados de los temas del worksheet
            $resultTemas = $queryTemas->result_array();
            for($i=0; $i<$cantTemas; $i++){
                $this->db->SELECT('temenun.Id_Tema, enun.*');
                $this->db->from('tema_enunciados temenun');
                $this->db->where('temenun.Id_Tema', $resultTemas[$i]['Id_Tema']);
                $this->db->join('enunciado_ws enun', 'temenun.Id_Enunciado = enun.Id_Enunciado');
                $queryEnunciados = $this->db->get();
                if(isset($queryEnunciados)){
                    $listado = array_merge($listado, $queryEnunciados->result_array());
                }
            }
        }

        $this->db->SELECT('curws.Id_Curso, curenunopc.*');                 // Obtenemos todos los Ids de los enunciado_ws generados de ese worksheet
        $this->db->from('curso_ws curws');
        $this->db->where('curws.Id_Ws', $data['Id_Ws']);
        $this->db->join('cursoenunciadoopcion curenunopc', 'curws.Id_CursoWs = curenunopc.Id_CursoWs');
        $queryEnunciadosGen = $this->db->get();
        $cantEnunciadosGen = $queryEnunciadosGen->num_rows();

        $idCurso = 0;
        $listadoEnunGen = array();
        if($cantEnunciadosGen > 0){                        // Obtenemos los datos de todos las enunciado_ws generados
            $resultEnunciadosGen = $queryEnunciadosGen->result_array();
            $idCurso = $resultEnunciadosGen[0]['Id_Curso'];
            for($i=0; $i<$cantEnunciadosGen; $i++){
                $this->db->SELECT('temenun.Id_Tema, enun.*');
                $this->db->from('enunciado_ws enun');
                $this->db->where('enun.Id_Enunciado', $resultEnunciadosGen[$i]['Id_Enunciado']);
                $this->db->join('tema_enunciados temenun', 'enun.Id_Enunciado = temenun.Id_Enunciado');
                $queryEnunciadosGenerados = $this->db->get();
                if(isset($queryEnunciadosGenerados)){
                    $listadoEnunGen = array_merge($listadoEnunGen, $queryEnunciadosGenerados->result_array());
                }
            }
        }

        $this->db->SELECT('Id_EstudianteWs');                 // Obtenemos el Id de estudiante_ws para saber si ya se realizo este Ws
        $this->db->from('estudiante_ws');
        $this->db->where('Id_Ws', $data['Id_Ws']);
        $queryWsHecho = $this->db->get();
        
        if(isset($queryTemas) && sizeof($listado) && sizeof($listadoEnunGen) && isset($queryWsHecho)){
            $cantRegistros = $queryWsHecho->num_rows();             //obtenemos la cant de registros de la Ws hecha para saber si ya se ha realizado al menos una vez

            $respuesta = array(
                'temas' => $queryTemas->result_array(),
                'enunciado_ws' => $listado,
                'idCurso' => $idCurso,
                'enunciadosGen' => $listadoEnunGen,
                'wsRealizado' => $cantRegistros
            );
        }
        $this->response($respuesta);
    }

    public function buscarWorksheetsEstudiante_post(){
        $data = $this->post();

        $this->db->SELECT('ws.Id_Ws, ws.Titulo, ws.Fecha_Inicio, ws.Fecha_Fin, ws.Intentos, ws.NotaTotal');
        $this->db->from('curso_ws');
        $this->db->where('curso_ws.Id_Curso', $data['Curso']);
        $this->db->join('worksheets ws', 'curso_ws.Id_Ws = ws.Id_Ws');
        $queryWorksheets = $this->db->get();

        $this->db->SELECT('Id_EstudianteWs, Id_Ws, Nota');
        $this->db->from('estudiante_ws');
        $this->db->where('Id_Estudiante', $data['Estudiante']);
        $queryEstudiantes = $this->db->get();
        
        if(isset($queryWorksheets) && isset($queryEstudiantes)){
            $cantidadFilas = $queryWorksheets->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'ws' => $queryWorksheets->result_array(),
                    'ws_estudiantes' =>$queryEstudiantes->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarEnunciadosWorksheets_post(){
        $data = $this->post();

        $this->db->SELECT('Password');
        $this->db->from('worksheets');
        $this->db->where('Id_Ws', $data['Id_Ws']);
        $queryPw = $this->db->get();
        $fila = $queryPw->row();
        
        if (isset($queryPw)){
            $this->db->SELECT('enws.*, opws.Id_Opcion, opws.Opcion, opws.Valor as ValorOpc');
            $this->db->from('worksheet_temasws wstm');
            $this->db->where('wstm.Id_Ws', $data['Id_Ws']);
            $this->db->join('temaws tm', 'wstm.Id_Tema = tm.Id_Tema');
            $this->db->join('tema_enunciados tmen', 'tm.Id_Tema = tmen.Id_Tema');
            $this->db->join('enunciado_ws enws', 'tmen.Id_Enunciado = enws.Id_Enunciado');
            $this->db->join('enunciado_opcion enop', 'enws.Id_Enunciado = enop.Id_Enunciado');
            $this->db->join('opciones_ws opws', 'enop.Id_Opcion = opws.Id_Opcion');
            $queryEnunciados = $this->db->get();
    
            if(isset($queryEnunciados)){
                $cantidadFilas = $queryEnunciados->num_rows();
                if($cantidadFilas > 0){
                    $respuesta = array(
                        'encontrado' => true,
                        'pw' => $fila->Password,
                        'enunciados' => $queryEnunciados->result_array()
                    );
                }else{
                    $respuesta = array(
                        'encontrado' => false
                    );
                }
            }
        }else{
            $respuesta = array(
                'encontrado' => false
            );
        }

        $this->response($respuesta);
    }

    public function buscarEnunciadosWorksheetsResp_post(){
        $data = $this->post();

        $this->db->SELECT('Id_EstudianteWs, Num_Intento, Nota');
        $this->db->from('estudiante_ws');
        $this->db->where('Id_Ws', $data['Id_Ws']);
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);
        $queryEstudianteWs = $this->db->get();
        $fila = $queryEstudianteWs->row();

        
        $this->db->SELECT('enws.*, opws.Id_Opcion, opws.Opcion, opws.Valor as ValorOpc');
        $this->db->from('worksheet_temasws wstm');
        $this->db->where('wstm.Id_Ws', $data['Id_Ws']);
        $this->db->join('temaws tm', 'wstm.Id_Tema = tm.Id_Tema');
        $this->db->join('tema_enunciados tmen', 'tm.Id_Tema = tmen.Id_Tema');
        $this->db->join('enunciado_ws enws', 'tmen.Id_Enunciado = enws.Id_Enunciado');
        $this->db->join('enunciado_opcion enop', 'enws.Id_Enunciado = enop.Id_Enunciado');
        $this->db->join('opciones_ws opws', 'enop.Id_Opcion = opws.Id_Opcion');
        $queryEnunciados = $this->db->get();

        $this->db->SELECT('Id_Enunciado, Id_Opcion, Respuesta');
        $this->db->from('worksheet_hecho');
        $this->db->where('Id_EstudianteWs', $fila->Id_EstudianteWs);
        $queryResp = $this->db->get();

        

        if(isset($queryEnunciados) && isset($queryResp)){
            $cantidadFilas = $queryEnunciados->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'enunciados' => $queryEnunciados->result_array(),
                    'resp' => $queryResp->result_array(),
                    'Id_EstudianteWs' => $fila->Id_EstudianteWs,
                    'intento' => $fila->Num_Intento,
                    'notaAnt' => $fila->Nota
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }

        $this->response($respuesta);
    }

    public function buscarWorksheetsHechos_post(){
        $data = $this->post();

        $this->db->SELECT('estu.Id_Estudiante, estu.Nombres, estu.Apellidos, estws.Nota');
        $this->db->from('estudiante_ws estws');
        $this->db->where('estws.Id_Ws', $data['Id_Ws']);
        $this->db->join('estudiante estu', 'estws.Id_Estudiante = estu.Id_Estudiante');
        $queryWs = $this->db->get();

        if(isset($queryWs)){
            $cantidadFilas = $queryWs->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'ws_hechas' => $queryWs->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarEnunciados_post(){
        $data = $this->post();

        $this->db->SELECT('enun.*');
        $this->db->from('tema_enunciados temenun');
        $this->db->where('temenun.Id_Tema', $data['Id_Tema']);
        $this->db->join('enunciado_ws enun', 'temenun.Id_Enunciado = enun.Id_Enunciado');
        $queryEnunciados = $this->db->get();

        if(isset($queryEnunciados)){
            $cantidadFilas = $queryEnunciados->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'enunciado_ws' => $queryEnunciados->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarEnunciadosTemas_post(){
        $data = $this->post();

        $listado = array();
        foreach($data as $tema){
            $this->db->SELECT('temenun.Id_Tema, enun.*');
            $this->db->from('tema_enunciados temenun');
            $this->db->where('temenun.Id_Tema', $tema['Id_Tema']);
            $this->db->join('enunciado_ws enun', 'temenun.Id_Enunciado = enun.Id_Enunciado');
            $queryEnunciados = $this->db->get();
            if(isset($queryEnunciados)){
                $listado = array_merge($listado, $queryEnunciados->result_array());
            }
        }

        if(sizeof($listado)){           // si el tamaño es 0 no entra
            $respuesta = array(
                'encontrado' => true,
                'enunciado_ws' => $listado
            );
        }else{
            $respuesta = array(
                'encontrado' => false
            );
        }
        $this->response($respuesta);
    }

    public function buscarOpciones_post(){
        $data = $this->post();

        $this->db->SELECT('opc.*');
        $this->db->from('enunciado_opcion enunopc');
        $this->db->where('enunopc.Id_Enunciado', $data['Id_Enunciado']);
        $this->db->join('opciones_ws opc', 'enunopc.Id_Opcion = opc.Id_Opcion');
        $queryOpcion = $this->db->get();

        if(isset($queryOpcion)){
            $cantidadFilas = $queryOpcion->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'opciones_ws' => $queryOpcion->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }


    /* TODOS LOS ELIMINAR DESDE ESTE PUNTO*/

    public function eliminarWorksheet_post(){
        $data = $this->post();
        $this->db->SELECT('Id_Estudiante');
        $this->db->from('estudiante_ws');
        $this->db->where('Id_Ws', $data['Id_Ws']);
        $queryWs = $this->db->get();


        if(isset($queryWs)){
            $cantidadFilas = $queryWs->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'This worksheet has already been taken by at least one student.'
                );
            }else{
                $this->db->SELECT('Id_CursoWs');                  // obtenemos el Id de curso_ws del worksheet
                $this->db->from('curso_ws');
                $this->db->where('Id_Ws', $data['Id_Ws']);
                $queryCursoWorksheet = $this->db->get();
                if(isset($queryCursoWorksheet)){
                    $cantFilasCurWork = $queryCursoWorksheet->num_rows();
                    if($cantFilasCurWork > 0){          // si hay registros en cursoenunciadoopcion eliminamos
                        $resultCurWork = $queryCursoWorksheet->result_array();
                        $this->db->where('Id_CursoWs', $resultCurWork[0]['Id_CursoWs']); // delete en tabla cursoenunciadoopcion
                        $this->db->delete('cursoenunciadoopcion');
                    }
                    $this->db->where('Id_Ws', $data['Id_Ws']);  // delete en tabla curso_ws
                    $this->db->delete('curso_ws');

                    $this->db->SELECT('Id_Tema');                  // obtenemos todos los temas del worksheet
                    $this->db->from('worksheet_temasws');
                    $this->db->where('Id_Ws', $data['Id_Ws']);
                    $queryTemas = $this->db->get();
    
                    if(isset($queryTemas)){
                        $this->db->where('Id_Ws', $data['Id_Ws']);  // delete en tabla worksheet_temasws
                        $this->db->delete('worksheet_temasws');
                        $cantFilasTemas = $queryTemas->num_rows();
    
                        if($cantFilasTemas > 0){
                            $temas = $queryTemas->result_array();
                            for ($iTema = 0; $iTema < $cantFilasTemas; $iTema++){
                                // Verificamos que los temas de ese worksheet no se usen en otros worksheets
                                $this->db->SELECT('Id_Ws');                  // buscamos si el tema a eliminar sigue constando en la tabla worksheet_temasws 
                                $this->db->from('worksheet_temasws');
                                $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);
                                $queryTemasUsados = $this->db->get();
    
                                if (isset($queryTemasUsados)){
                                    $cantFilasTemasUsados = $queryTemasUsados->num_rows();
                                    if($cantFilasTemasUsados == 0){          // si el tema ya no se usa lo eliminamos
                                        $this->db->SELECT('Id_Enunciado');                  // obtenemos todos los enunciados del tema
                                        $this->db->from('tema_enunciados');
                                        $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);
                                        $queryEnunciados = $this->db->get();
            
                                        if(isset($queryEnunciados)){
                                            $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);  // delete en tabla tema_enunciados
                                            $this->db->delete('tema_enunciados');
                                            $cantidadFilasEnun = $queryEnunciados->num_rows();
            
                                            if($cantidadFilasEnun > 0){
                                                $enunciados = $queryEnunciados->result_array();
                                                for ($iEnun = 0; $iEnun < $cantidadFilasEnun; $iEnun++){
                                                    $this->db->SELECT('Id_Opcion');                  // obtenemos todas las opciones de ese enunciado
                                                    $this->db->from('enunciado_opcion');
                                                    $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);
                                                    $queryOpcion = $this->db->get();
                                                    
                                                    if(isset($queryOpcion)){
                                                        $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);  // delete en tabla enunciado_opcion
                                                        $this->db->delete('enunciado_opcion');
                                                        $cantidadFilasOpc = $queryOpcion->num_rows();
            
                                                        if($cantidadFilasOpc > 0){
                                                            $enunci = $queryOpcion->result_array();
                                                            for ($iOpcs = 0; $iOpcs < $cantidadFilasOpc; $iOpcs++){
                                                                $this->db->where('Id_Opcion', $enunci[$iOpcs]['Id_Opcion']);  // eliminamos las opciones del enunciado
                                                                $this->db->delete('opciones_ws');
                                                            }
                                                        }
                                                        $this->db->SELECT('Imagen');                    // Buscamos la imagen de ese enunciado si tuviese
                                                        $this->db->from('enunciado_ws');
                                                        $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);
                                                        $queryImagen = $this->db->get();

                                                        if(isset($queryImagen)){
                                                            $imagen = $queryImagen->result_array();
                                                            $imgAnterior = $imagen[0]['Imagen'];        // obtenemos el nombre de la imagen, si no tiene devuelve null
                                                            if ($imgAnterior != null){                  // si existe una imagen la eliminamos de la carpeta
                                                                $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/worksheets/" . $imgAnterior;
                                                                Unlink($ruta);
                                                            }
                                                        }
                                                        $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);  // delete en tabla enunciado_ws
                                                        $this->db->delete('enunciado_ws');
                                                    }
                                                }
                                            }
                                            $this->db->where('Id_Tema', $temas[$iTema]['Id_Tema']);  // delete en tabla tema
                                            $this->db->delete('temaws');
                                        }
                                    }
                                }
                            }
                        }
                        $this->db->where('Id_Ws', $data['Id_Ws']);  // delete en tabla worksheets
                        $this->db->delete('worksheets');
        
                        $respuesta = array(
                            'error' => false,
                            'mensaje' => 'Worksheets eliminada Correctamente'
                        );
                    }
                }
            }
        }
        $this->response($respuesta);
    }

    public function eliminarTema_post(){
        $data = $this->post();
        $this->db->SELECT('Id_Ws');
        $this->db->from('worksheet_temasws');
        $this->db->where('Id_Tema', $data['Id_Tema']);
        $queryWorksheet = $this->db->get();

        if(isset($queryWorksheet)){
            $cantidadFilas = $queryWorksheet->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'This Topic is being used in a Generated Worksheet'
                );
            }else{
                $this->db->SELECT('temenun.Id_Enunciado, enun.Imagen');                  // obtenemos todos los enunciados del tema
                $this->db->from('tema_enunciados temenun');
                $this->db->where('temenun.Id_Tema', $data['Id_Tema']);
                $this->db->join('enunciado_ws enun', 'temenun.Id_Enunciado = enun.Id_Enunciado');
                $queryEnunciados = $this->db->get();
                
                if(isset($queryEnunciados)){
                    $this->db->where('Id_Tema', $data['Id_Tema']);  // delete en tabla tema_enunciados
                    $this->db->delete('tema_enunciados');
                    $cantidadFilasEnun = $queryEnunciados->num_rows();

                    if($cantidadFilasEnun > 0){
                        $enunciados = $queryEnunciados->result_array();
                        for ($iEnun = 0; $iEnun < $cantidadFilasEnun; $iEnun++){
                            $this->db->SELECT('Id_Opcion');                  // obtenemos todas las opciones de ese enunciado
                            $this->db->from('enunciado_opcion');
                            $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);
                            $queryOpcion = $this->db->get();
                            
                            if(isset($queryOpcion)){
                                $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);  // delete en tabla enunciado_opcion
                                $this->db->delete('enunciado_opcion');
                                $cantidadFilasOpc = $queryOpcion->num_rows();
                                if($cantidadFilasOpc > 0){
                                    $opcins = $queryOpcion->result_array();
                                    for ($i = 0; $i < $cantidadFilasOpc; $i++){
                                        $this->db->where('Id_Opcion', $opcins[$i]['Id_Opcion']);  // eliminamos las opciones del enunciado
                                        $this->db->delete('opciones_ws');
                                    }
                                }
                                $this->db->where('Id_Enunciado', $enunciados[$iEnun]['Id_Enunciado']);  // delete en tabla enunciado_ws
                                $this->db->delete('enunciado_ws');

                                if ($enunciados[$iEnun]['Imagen'] != null){           // si la pregunta tiene imagen la eliminamos de la carpeta
                                    $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/worksheets/" . $enunciados[$iEnun]['Imagen'];
                                    Unlink($ruta);
                                }
                            }

                        }
                    }
                    $this->db->where('Id_Tema', $data['Id_Tema']);  // delete en tabla tema
                    $this->db->delete('temaws');
                }

                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Tema eliminado Correctamente'
                );
            }
        }
        $this->response($respuesta);
    }

    public function eliminarEnunciado_post(){
        $data = $this->post();
        $this->db->SELECT('Id_CursoWs');                    // Buscamos si el enunciado se encuentra en un worksheet generado
        $this->db->from('cursoenunciadoopcion');
        $this->db->where('Id_Enunciado', $data['Id_Enunciado']);
        $queryEnunciado = $this->db->get();
        if(isset($queryEnunciado)){
            $cantidadFilas = $queryEnunciado->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'This statement is being used in a generated worksheet.'
                );
            }else{
                $this->db->where('Id_Enunciado', $data['Id_Enunciado']);  // delete en tabla tema_enunciados
                $this->db->delete('tema_enunciados');

                $this->db->SELECT('Id_Opcion');                  // obtenemos todas las opciones de ese worksheet
                $this->db->from('enunciado_opcion');
                $this->db->where('Id_Enunciado', $data['Id_Enunciado']);
                $queryOpcion = $this->db->get();

                $this->db->where('Id_Enunciado', $data['Id_Enunciado']);  // delete en tabla enunciado_opcion
                $this->db->delete('enunciado_opcion');

                if(isset($queryOpcion)){
                    $cantidadFilas = $queryOpcion->num_rows();
                    if($cantidadFilas > 0){
                        $resptas = $queryOpcion->result_array();
                        for ($i = 0; $i < $cantidadFilas; $i++){
                            $this->db->where('Id_Opcion', $resptas[$i]['Id_Opcion']);  // eliminamos las opciones del enunciado
                            $this->db->delete('opciones_ws');
                        }
                    }
                }

                $this->db->where('Id_Enunciado', $data['Id_Enunciado']);  // delete en tabla enunciado_ws
                $this->db->delete('enunciado_ws');

                if ($data['Imagen'] != null){           // si la pregunta tiene imagen la eliminamos de la carpeta
                    $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/worksheets/" . $data['Imagen'];
                    Unlink($ruta);
                }

                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Enunciado eliminado Correctamente'
                );
            }
        }
        $this->response($respuesta);
    }

    public function eliminarOpcion_post(){
        $data = $this->post();
        $this->db->SELECT('*');
        $this->db->from('worksheet_hecho');
        $this->db->where('Id_Opcion', $data['Id_Opcion']);
        $queryOpcion = $this->db->get();
        if(isset($queryOpcion)){
            $cantidadFilas = $queryOpcion->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'error' => true,
                    'mensaje' => 'This option is being used in a worksheet already performed.'
                );
            }else{
                $this->db->where('Id_Opcion', $data['Id_Opcion']);  // tabla enunciado_opcion
                $this->db->delete('enunciado_opcion');
                $this->db->where('Id_Opcion', $data['Id_Opcion']);  // tabla opciones_ws
                $this->db->delete('opciones_ws');
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'The option was successfully deleted'
                );
            }
        }
        $this->response($respuesta);
    }

     /**TODOS LOS ACTUALIZAR DESDE AQUÍ**/

/*      public function actualizarWorksheetGenerado_post(){
        $data = $this->post();

        $worksheet = $data['Worksheet'];
        $enunciado = $data['Enunciado'];

        $datosWorksheet = [
            'Password' => $worksheet['Password']
        ];
        $this->db->where('Id_Ws', $worksheet['Id_Ws']);          // actualizamos los datos de la worksheet
        $this->db->update('worksheet', $datosWorksheet);

        $this->db->SELECT('Id_Enunciado');                       // Buscamos todos los enunciado de esa worksheet
        $this->db->from('worksheets_enunciados');
        $this->db->where('Id_Ws', $worksheet['Id_Ws']);
        $queryEnunciados = $this->db->get();

        if (isset($queryEnunciados)){
            $cantidadFilas = $queryEnunciados->num_rows();
            $enunciadosWorksheet = $queryEnunciados->result_array();
            for ($i = 0; $i < $cantidadFilas; $i++){                // actualizamos todos los mostrar de enunciado a 0
                $this->db->where('Id_Enunciado', $enunciadosWorksheet[$i]['Id_Enunciado']);  
                $this->db->update('enunciado_ws', ['Mostrar' => 0]);          
            }
            foreach ($enunciado as $enun){          // actualizamos los mostrar de las enunciado generadas a 1
                $this->db->where('Id_Enunciado', $enun['Id_Enunciado']);  
                $this->db->update('enunciado_ws', ['Mostrar' => 1]); 
            }
            $respuesta = array(
                'error' => false
            );
        }else{
            $respuesta = array(
                'error' => true
            );
        }
        $this->response($respuesta);
    } */



}
