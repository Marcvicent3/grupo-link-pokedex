<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class CuentosService extends REST_Controller
{
    public function __construct(){
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");
        parent::__construct();
        $this->load->database();
    }

    public function index_get(){
        $queryCuentos = $this->db->query("SELECT * FROM `cuento`");


        $respuesta = array(
            'error' => false,
            'cuentos' => $queryCuentos->result_array()
        );

        $this->response($respuesta);
    }

    //*******************************************************
    //********** TODOS LOS MOSTRAR EN ESTA SECCIÓN **********

    public function obtenerCuentos_get(){
        $queryCuentos = $this->db->query("SELECT * FROM `cuento`");

        $respuesta = array(
            'error' => false,
            'cuentos' => $queryCuentos->result_array()
        );
        $this->response($respuesta);
    }

    //********************************************************
    //********** TODOS LOS INGRESAR EN ESTA SECCIÓN **********

    public function ingresarCuento_post(){
        $data = $this->post();
        $id = null;
        $datos = array(
            'Titulo' => $data['Titulo'],
            'Parrafo' => $data['Parrafo'],
            'Autor' => $data['Autor'],
            'Referencia' => $data['Referencia']
        );

        if(isset($data['Id_Cuento'])){
            $id = $data['Id_Cuento'];
        }

        if (($id == null)) {
            $this->db->insert('cuento', $datos);
            $NuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'El cuento se guardo correctamente',
                'id_nuevo' => $NuevoId
            );
            $this->response($respuesta);
        } else {
            $this->db->where('Id_Cuento', $id);
            $this->db->update('cuento', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'El cuento se actualizo correctamente',
                );
            $this->response($respuesta);
        }
    }

    //********************************************************
    //********** TODOS LOS ELIMINAR EN ESTA SECCIÓN **********

    public function eliminarCuento_post(){
        $data = $this->post();
        $this->db->where('Id_Cuento', $data['Id_Cuento']);  // delete en tabla cuento
        $this->db->delete('cuento');

        if ($data['Imagen'] != null){           // si la pregunta tiene imagen la eliminamos de la carpeta
            $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/cuentos/" . $data['Imagen'];
            Unlink($ruta);
        }
        
        $respuesta = array(
            'error' => false,
            'mensaje' => 'El cuento se eliminó correctamente'
        );
        $this->response($respuesta);
    }
}
