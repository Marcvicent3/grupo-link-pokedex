<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class PersonaService extends REST_Controller
{
    public function __construct(){
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");
        parent::__construct();
        $this->load->database();
    }

    public function index_get(){
        $respuesta = 'PersonaService-index_get()';
        $this->response($respuesta);
    }

    // TODOS LOS MOSTRAR EN ESTA SECCIÓN
    public function obtenerEstudiantes_get(){
        $this->db->SELECT('est.*, cur.Id_Curso, cur.Grado, cur.Paralelo, padest.Id_Persona');
        $this->db->from('estudiante est');
        $this->db->join('estudiante_curso estcur', 'est.Id_Estudiante = estcur.Id_Estudiante');
        $this->db->join('curso cur', 'estcur.Id_Curso = cur.Id_Curso');
        $this->db->join('padre_estudiante padest', 'est.Id_Estudiante = padest.Id_Estudiante');
        $this->db->order_by('cur.Grado ASC, cur.Paralelo ASC, est.Apellidos, est.Nombres');
        $queryEstudiante = $this->db->get();

        if (isset($queryEstudiante)){
            $cantidadFilas = $queryEstudiante->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true,
                    'estudiantes' => $queryEstudiante->result_array()
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }

            $this->response($respuesta);
        }
    }

    public function obtenerCursos_get(){
        $this->db->SELECT('*');
        $this->db->from('curso');
        $this->db->order_by('Grado ASC, Paralelo ASC');
        $queryCursos = $this->db->get();

        if (isset($queryCursos)){
            $respuesta = array(
                'cursos' => $queryCursos->result_array()
            );
            $this->response($respuesta);
        }
    }

    // TODOS LOS INGRESAR EN ESTA SECCIÓN

    public function ingresarPersona_post(){
        $data = $this->post();
        $id = $data['Id_Persona'];

        $datos = [
            'Nombres' => $data['Nombres'],
            'Apellidos' => $data['Apellidos'],
            'CI' => $data['CI'],
            'Correo' => $data['Correo'],
            'Celular' => $data['Celular'],
            'Pw' => base64_encode($data['Pw']),
            'Id_Tipo' => $data['Id_Tipo'],
        ];

        if (($id == null)) {
            $this->db->insert('persona', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Persona guardada correctamente',
                'id_nuevo' => $nuevoId
            );
            $this->response($respuesta);
        } else {
            $this->db->where('Id_Persona', $id);
            $this->db->update('persona', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'Persona actualizada correctamente'
                );
            $this->response($respuesta);
        }
    }

    public function ingresarEstudiante_post(){
        $data = $this->post();
        $idEst = $data['Id_Estudiante'];

        $datosEst = [
            'Nombres' => $data['Nombres'],
            'Apellidos' => $data['Apellidos'],
            'CI' => $data['CI'],
            'Id_Tipo' => $data['Id_Tipo'],
            'Usuario' => $data['Usuario'],
            'Password' => base64_encode($data['Password'])
        ];
        
        if (($idEst == null)) {
            $this->db->insert('estudiante', $datosEst);
            $nuevoId = $this->db->insert_id();
            $datosCurso = [
                'Id_Curso' => $data['Id_Curso'],
                'Id_Estudiante' => $nuevoId
            ];
            $this->db->insert('estudiante_curso', $datosCurso);
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Estudiante guardado correctamente',
                'id_nuevo' => $nuevoId
            );
            $this->response($respuesta);
        } else {
            $datosCurso = [
                'Id_Curso' => $data['Id_Curso']
            ];
            $this->db->where('Id_Estudiante', $idEst);
            $this->db->update('estudiante', $datosEst);

            $this->db->where('Id_Estudiante', $idEst);
            $this->db->update('estudiante_curso', $datosCurso);
            $respuesta = array(
                'error' => false,
                'mensaje' => 'Estudiante actualizado correctamente'
            );
            $this->response($respuesta);
        }
    }

    public function ingresarPadreEstudiante_post(){
        $data = $this->post();

        $datos = [
            'Id_Persona' => $data['Id_Persona'],
            'Id_Estudiante' => $data['Id_Estudiante']
        ];
        
        $this->db->insert('padre_estudiante', $datos);
        $respuesta = array(
            'error' => false,
        );
        $this->response($respuesta);
    }

    // TODOS LOS ELIMINAR EN ESTA SECCIÓN

    public function eliminarEstudiante_post(){
        $data = $this->post();

        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla estudiante_curso
        $this->db->delete('estudiante_curso');
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla estudiante_prueba
        $this->db->delete('estudiante_prueba');
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla prueba_hecha
        $this->db->delete('prueba_hecha');
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla estudiante_ws
        $this->db->delete('estudiante_ws');
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla worksheet_hecho
        $this->db->delete('worksheet_hecho');

        $this->db->SELECT('Id_Estudiante');     // buscamos si el id del padre se usa en otros estudiantes             
        $this->db->from('padre_estudiante');
        $this->db->where('Id_Persona', $data['Id_Persona']);
        $queryEstudiante = $this->db->get();

        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla padre_estudiante 
        $this->db->delete('padre_estudiante');
        $this->db->where('Id_Estudiante', $data['Id_Estudiante']);  // tabla estudiante
        $this->db->delete('estudiante');

        if(isset($queryEstudiante)){                // eliminamos los datos del padre si no se usa en otros estudiantes
            $cantidadFilas = $queryEstudiante->num_rows();
            if($cantidadFilas < 2){             // el id del padre solo tiene un estudiante asignado (eliminar)
                $this->db->where('Id_Persona', $data['Id_Persona']);
                $this->db->delete('persona');
            }
        }

        $respuesta = array(
            'error' => false,
            'mensaje' => 'Estudiante eliminado correctamente'
        );
        $this->response($respuesta);
    }

    //****************************************************** 
    //********** TODOS LOS BUSCAR EN ESTA SECCIÓN ********** 

    public function buscarPersona_post(){
        $data = $this->post();

        $this->db->SELECT('Id_Persona');
        $this->db->from('persona');
        $this->db->where('CI', $data['CI']);
        $queryPersona = $this->db->get();

        if(isset($queryPersona)){
            $cantidadFilas = $queryPersona->num_rows();
            if($cantidadFilas > 0){
                $Persona = $queryPersona->result_array();
                $respuesta = array(
                    'encontrado' => true,
                    'Id_Persona' => $Persona[0]['Id_Persona']
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarEstudiante_post(){
        $data = $this->post();

        $this->db->SELECT('Id_Estudiante');
        $this->db->from('estudiante');
        $this->db->where('CI', $data['CI']);
        $queryEstudiante = $this->db->get();

        if(isset($queryEstudiante)){
            $cantidadFilas = $queryEstudiante->num_rows();
            if($cantidadFilas > 0){
                $respuesta = array(
                    'encontrado' => true
                );
            }else{
                $respuesta = array(
                    'encontrado' => false
                );
            }
        }
        $this->response($respuesta);
    }

    public function buscarRepresentante_post(){
        $data = $this->post();

        $this->db->SELECT('per.*');
        $this->db->from('padre_estudiante padest');
        $this->db->where('padest.Id_Estudiante', $data['Id_Estudiante']);
        $this->db->join('persona per', 'padest.Id_Persona = per.Id_Persona');
        $queryRepresentante = $this->db->get();

        if(isset($queryRepresentante)){
            $respuesta = array(
                'encontrado' => true,
                'representante' => $queryRepresentante->result_array()
            );
        }
        $this->response($respuesta);
    }

    //****************************************************** 
    //********** TODOS LOS otros metodos EN ESTA SECCIÓN ********** 

    public function login_post(){
        $data = $this->post();

        if (!isset($data['Usuario']) or !isset($data['Password'])) {
        $respuesta = array(
            'error' => true,
            'mensaje' => 'Fill in all fields before proceeding.'
        );
        $this->response($respuesta, REST_Controller::HTTP_BAD_REQUEST);
        return;
        }
        $password = base64_encode($data['Password']);

        $query = $this->db->query("SELECT * FROM estudiante WHERE Usuario = BINARY '{$data['Usuario']}' AND Password = BINARY '{$password}'");
        $estudiante = $query->row();

        if (!isset($estudiante)) {
            $respuesta = array(
            'error' => true,
            'mensaje' => 'User and/or password are not valid',
            );
            $this->response($respuesta);
            return;
        }

        $this->db->SELECT('cur.Id_Curso, cur.Grado, cur.Paralelo, padest.Id_Persona');
        $this->db->from('estudiante est');
        $this->db->where('est.Id_Estudiante',$estudiante->Id_Estudiante);
        $this->db->join('estudiante_curso estcur', 'est.Id_Estudiante = estcur.Id_Estudiante');
        $this->db->join('curso cur', 'estcur.Id_Curso = cur.Id_Curso');
        $this->db->join('padre_estudiante padest', 'est.Id_Estudiante = padest.Id_Estudiante');
        $queryEstudiante = $this->db->get();
        $fila = $queryEstudiante->row();

        $estudiante->Id_Curso = $fila->Id_Curso;
        $estudiante->Grado = $fila->Grado ;
        $estudiante->Paralelo = $fila->Paralelo;
        $estudiante->Id_Persona = $fila->Id_Persona;

        $respuesta = array(
            'error' => false,
            'informacion' => $estudiante,
        );
        $this->response($respuesta);
    }

    public function loginAd_post(){
        $data = $this->post();

        if (!isset($data['Usuario']) or !isset($data['Password'])) {
        $respuesta = array(
            'error' => true,
            'mensaje' => 'Fill in all fields before proceeding.'
        );
        $this->response($respuesta, REST_Controller::HTTP_BAD_REQUEST);
        return;
        }
        $password = base64_encode($data['Password']);

        $query = $this->db->query("SELECT * FROM persona WHERE Correo = BINARY '{$data['Usuario']}' AND Pw = BINARY '{$password}' AND Id_Tipo = '1'");
        $persona = $query->row();

        if (!isset($persona)) {
            $respuesta = array(
            'error' => true,
            'mensaje' => 'User and/or password are not valid',
            );
            $this->response($respuesta);
            return;
        }

        $respuesta = array(
            'error' => false,
            'informacion' => $persona,
        );
        $this->response($respuesta);
    }

    /* Notificaciones Push */

    public function sendMessage_post() {
        $data = $this->post();

        $content = array(
            "en" => $data['Comunicado']
        );
        $headings = array(
            "en" => $data['Titulo']
        );
        $imagen = 'http://servicios-tesis.marcelo-romero.com/restServices/notificacion.png';

        $fields = array(
            'app_id' => "28c54eb5-08ec-4299-9c99-9f7a708cf4d9",
            'included_segments' => array(
                'Active Users',
                'Unactive Users'
            ),
            'data' => array(
                "foo" => "bar"
            ),
            'contents' => $content,
            'headings' => $headings,
            'big_picture' => $imagen
        );
        
        $fields = json_encode($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic ZDE3ZWJjY2ItOGY5ZS00MTI1LWEzNTUtNjA4ZjE5Mzg3YjVj'
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        
        $response = curl_exec($ch);
        curl_close($ch);

        $respuesta = array(
            'error' => false
        );
        $this->response($respuesta);
        
        // return $response;
    }
}
