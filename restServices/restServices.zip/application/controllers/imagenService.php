<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class imagenService extends REST_Controller
{
    public function __construct()
    {

        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
        header("Access-Control-Allow-Origin: *");


        parent::__construct();
        $this->load->database();
    }

    public function index_get()
    {
        $respuesta = 'ImagenService-index_get()';
        $this->response($respuesta);
    }

    public function actualizarImagen_post(){
        $data = $this->post();
        $json = file_get_contents('php://input'); // RECIBE EL JSON DE ANGULAR

        $params = json_decode($json); // DECODIFICA EL JSON Y LO GUARADA EN LA VARIABLE

        $nombreArchivo = $params->nombreArchivo;
        $archivo = $params->base64textString;
        $archivo = base64_decode($archivo);
        $tabla = $params->tabla;
        $campo = $params->id;
        $columna = $params->columna;
        
        $this->db->SELECT('Imagen');                    // Buscamos el nombre actual de la imagen de ese registro
        $this->db->from($tabla);
        $this->db->where($columna, $campo);
        $queryImagen = $this->db->get();

        if(isset($queryImagen)){
            $imagen = $queryImagen->result_array();
            $imgAnterior = $imagen[0]['Imagen'];        // obtenemos el nombre de la imagen que esta en la base, si no tiene devuelve null

            $imageFileType = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));      // Obtenemos el tipo del archivo
    
            $nuevoNombre = "{$campo}-{$tabla}.{$imageFileType}";            // Creamos un nombre para la base
            $datos = array('Imagen' => $nuevoNombre);
    
            $this->db->where($columna, $campo);
            $this->db->update($tabla, $datos); 
    
            if($tabla == 'prueba'){
                $filePath = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/pruebas/";
            }elseif($tabla == 'enunciado_ws'){
                $filePath = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/worksheets/"; // revisar por que esta entrando en otro lugar las imagenes
            }elseif($tabla == 'cuento'){
                $filePath = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/cuentos/";
            }elseif($tabla == 'juegos_clase'){
                $filePath = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/juegos/";
            }elseif($tabla == 'preguntas'){
                $filePath = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/preguntas/";
            }elseif($tabla == 'comunicados'){
                $filePath = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/comunicados/";
            }

            if ($imgAnterior != null && $imgAnterior != $nuevoNombre){      // condicion para borrar de la carpeta la imagen anterior de ese registro que tiene otra extencion
                $ruta =  $filePath . $imgAnterior;                          //  para evitar multiples imagenes de un mismo registro, si tiene el mismo nombre automaticamente se reemplaza
                Unlink($ruta);
            }
            $filePath = $filePath . $nuevoNombre;
            file_put_contents($filePath, $archivo);         // guardamos la imagen en la carpeta
    
            $respuesta = array(
                'error' => false,
            );
        }    
        $this->response($respuesta);
    }

    /* COMUNICADOS */

    
    public function obtenerComunicados_get(){
        $queryComunicados = $this->db->query("SELECT * FROM `comunicados`");

        $respuesta = array(
            'error' => false,
            'comunicados' => $queryComunicados->result_array()
        );
        $this->response($respuesta);
    }

    //********************************************************
    //********** TODOS LOS INGRESAR EN ESTA SECCIÓN **********

    public function ingresarComunicado_post(){
        $data = $this->post();
        $id = null;
        $datos = array(
            'Titulo' => $data['Titulo'],
            'Comunicado' => $data['Comunicado'],
            'Fecha' => $data['Fecha']
        );

        if(isset($data['Id_Comunicado'])){
            $id = $data['Id_Comunicado'];
        }

        if (($id == null)) {
            $this->db->insert('comunicados', $datos);
            $nuevoId = $this->db->insert_id();
            $respuesta = array(
                'error' => false,
                'mensaje' => 'El Comunicado se guardo correctamente',
                'id_nuevo' => $nuevoId
            );
            $this->response($respuesta);
        } else {
            $this->db->where('Id_Comunicado', $id);
            $this->db->update('comunicados', $datos);
                $respuesta = array(
                    'error' => false,
                    'mensaje' => 'El Comunicado se actualizo correctamente',
                );
            $this->response($respuesta);
        }
    }

    //********************************************************
    //********** TODOS LOS ELIMINAR EN ESTA SECCIÓN **********

    public function eliminarComunicado_post(){
        $data = $this->post();
        $this->db->where('Id_Comunicado', $data['Id_Comunicado']);  // delete en tabla Comunicado
        $this->db->delete('comunicados');

        if ($data['Imagen'] != null){           // si la pregunta tiene Documento la eliminamos de la carpeta
            $ruta = $_SERVER['DOCUMENT_ROOT'] . "/TESIS-FINAL/restServices/public/comunicados/" . $data['Imagen'];
            Unlink($ruta);
        }
        
        $respuesta = array(
            'error' => false,
            'mensaje' => 'El Comunicado se eliminó correctamente'
        );
        $this->response($respuesta);
    }

}
