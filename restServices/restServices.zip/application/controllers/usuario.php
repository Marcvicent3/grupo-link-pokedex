<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . '/libraries/REST_Controller.php');

use Restserver\libraries\REST_Controller;

class Usuarioservice extends REST_Controller
{
 
    public function __construct()
    {
  
      header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
      header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
      header("Access-Control-Allow-Origin: *");
      parent::__construct();
      $this->load->database();
    }

    public function login_post() {

        $data = $this->post();
    
        if (!isset($data['correo']) or !isset($data['password'])) {
    
          $respuesta = array(
            'error' => true,
            'mensaje' => 'Llene todos los campos antes de continuar.'
          );
          $this->response($respuesta, REST_Controller::HTTP_BAD_REQUEST);
          return;
        }
    
        $condiciones = array(
          'correo' => $data['correo'],
          'password' => md5($data['password'])
        );
    
        $query = $this->db->get_where('usuarios', $condiciones);
        
        $usuario = $query->row();
    
        if (!isset($usuario)) {
          $respuesta = array(
            'error' => true,
            'mensaje' => 'Usuario y/o password no son validos'
          );
          $this->response($respuesta);
          return;
        }
    
        $respuesta = array(
            'error' => false,
            'informacion' => $usuario
          );
          $this->response($respuesta);

      }
}
